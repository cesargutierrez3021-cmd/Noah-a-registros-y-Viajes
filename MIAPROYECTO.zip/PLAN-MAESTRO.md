# MIA — Plan maestro

> **Instrucción para cualquier sesión nueva (Claude u otra persona):** lee este archivo primero, completo, antes de tocar código. Aquí está el estado real: qué fase va, qué se decidió y por qué, y qué sigue exactamente. No releer el proyecto viejo (NOAH Conductor) salvo que se busque un dato puntual de funcionalidad — ese proyecto es solo referencia, nunca se copia código de ahí (excepción: plugins nativos de Android, ver decisión D-1).

> **Regla de comunicación durante el trabajo (pedida explícitamente por el usuario):** mientras se está trabajando en una sección/bloque, NO mandar mensajes narrando el progreso paso a paso — trabajar en silencio y solo escribir cuando: (a) hace falta preguntarle algo al usuario porque es una decisión real que cambiaría el resultado (no una duda que se puede resolver leyendo el código), o (b) pasó un error real que bloquea seguir. Al terminar una sección/bloque completo, entregar directamente el zip actualizado (con este plan actualizado adentro) sin preámbulo largo — un resumen breve de qué se hizo y cuál es el siguiente paso, y ya.

Última actualización: **Bloque 4 — parte visual, SOLO Panel "Trabajo" (pedido explícito del usuario: "solo hace el diseño visual de la parte del trabajo... no me toques balance ni nada más por ahora").** Ver "Estado real de Bloque 4 — parte visual (solo Panel Trabajo)" para el detalle completo. Balance, Casa y Deudas, Cuenta y Planes siguen exactamente con el tema genérico de siempre — no se tocó ni una línea de esas pantallas.

Antes de esto: **Bloque 4 (rediseño visual) — parte NO visual hecha, en 2 secciones (pedido explícito del usuario: hacer todo lo que no sea diseño/tema, dejando esa parte para después).** Ver "Estado real de Bloque 4 — parte no visual" para el detalle completo de las 2 secciones.

Antes de esto: **✅ Bloque 3 (dominios nuevos) COMPLETO — las 4 secciones.** Sección 4/4 (Balance general) hecha esa sesión — ver "Estado real de Bloque 3 — sección 4: Balance general" para el detalle.

Antes de esto: **Bloque 3 — sección 3 de 4: `domain/hogar` HECHO.** Ver "Estado real de Bloque 3 — sección 3: domain/hogar" para el detalle completo.

Antes de esto: **Bloque 3 — sección 2 de 4: `domain/deudas` HECHO.** Ver "Estado real de Bloque 3 — sección 2: domain/deudas" para el detalle completo (incluye una decisión de diseño nueva: `Deuda` es la primera entidad de Bloque 3 que se sincroniza MUTABLE, con FK real de `AbonoDeuda` hacia ella, y el manejo de orden que eso exige).

Antes de esto: **Bloque 3 — sección 1 de 4: `domain/gastos` HECHO.** El usuario pidió avanzar el Bloque 3 completo (gastos/deudas/hogar/balance) en 4 secciones, actualizando este plan después de cada una. Se agregó `domain/gastos` completo (cliente: types/repository/store/api/sync + `GastosScreen.tsx` sin vestir + ruta `/gastos`; backend: modelo Prisma `Gasto` + extensión del módulo `sync` con `POST /sync/gastos`, mismo diseño push-only con upsert por id que ya usan viajes/jornada/mantenimiento). Detalle completo en "Estado real de Bloque 3 — sección 1: domain/gastos".

Antes de esto: **✅ Bloque 2 (funciones nuevas de bajo riesgo) COMPLETO — los 2 ítems.**

**Ítem 3 — tiempo real/muerto de jornada + $/hora:** dos funciones puras nuevas en `domain/estadisticas/calculos.ts` (se extendió ese archivo, no se creó otro): `calcularTiempoJornada(jornada, viajes)` cruza `Jornada.viajesIds` con `Viaje.inicioISO/finISO` para dar tiempo total / trabajado / muerto (nunca negativo, incluso si un viaje manual mal tipeado dura más que la jornada entera); `calcularRentabilidadPorHora(jornada, viajes)` reutiliza esa función (D-18: no duplicar el cálculo de tiempo) para dar `ingresoPorHoraTrabajada` (solo horas con pasajero) vs `ingresoPorHoraConEspera` (toda la jornada, incluida la espera). Ambas son funciones puras — reciben `Jornada`+`Viaje[]` como parámetros, no importan ningún store (D-10). Verificado con `node`: jornada de 4h con 1h trabajada da $/hora-trabajada = 4× el $/hora-con-espera, un viaje de otra jornada se ignora correctamente, una jornada abierta usa "ahora" como fin provisional, y un viaje manual mal tipeado no produce tiempo muerto negativo. **A propósito sin pantalla todavía** — el plan de bloques deja la UI de estas métricas para el Bloque 4 (tarjeta de pulso), esto solo eran "las funciones puras" que pedía el ítem 3.

**Ítem 4 — agregar viaje manual:** nueva pantalla `AgregarViajeManualScreen.tsx` (ruta `/viajes/manual`, enlazada desde un botón en `ViajesScreen.tsx` — sin pestaña propia en la barra de navegación a propósito, es una acción secundaria, no una sección nueva). Reutiliza el mismo `Viaje` de siempre (D-18: no se inventó un tipo "viaje manual" aparte) — se extendió `domain/viajes/types.ts` (`ViajeManualInput`) y `repository.ts` (`crearViajeManual`, hermana de `crearViajeDesdeCiere`: mismo `Viaje`, pero `recorrido: []` y `distancia` armada directo del km que el conductor escribe, en vez de calcularse desde puntos GPS que acá no existen). El store de viajes se extendió con `agregarViajeManual` (no toca `viajeEnCurso` ni el GPS). La pantalla, si hay una jornada abierta, también llama a `agregarViajeAJornadaAbierta` — mismo patrón de orquestación que ya usa `ViajesScreen.tsx`. Confirmado que el resultado es 100% compatible con lo que ya existe sin tocar nada más: mismo shape que consume `calcularResumen`/`agruparPorPeriodo`/`calcularTiempoJornada`, y el schema de sync (`esquemaViajeSync`) ya aceptaba `recorrido: []` sin cambios.

**Bloque 2 completo. Antes de seguir con el Bloque 3 (dominios nuevos: gastos, deudas, hogar), se le preguntó al usuario si continúa.**

Antes de esto: **✅ Bloque 1 (bugs) COMPLETO — los 2 ítems.**

**Ítem 1 — GPS en segundo plano (try/catch):** el usuario asumía que ya estaba resuelto ("ese está bien ya"), pero se verificó el código directamente y el fix NO estaba aplicado (`iniciarViaje` en `domain/viajes/store.ts` seguía llamando a `iniciarSeguimientoGPS(...)` sin ningún `try/catch`). Se corrigió: si el GPS falla al iniciar (permiso negado, GPS apagado, plugin nativo sin registrar), ahora se captura el error, se cancela el viaje en curso (no queda "iniciado" con el GPS realmente caído) y se expone `errorGPS` en el store — `ViajesScreen.tsx` lo muestra en pantalla. Antes quedaba en silencio.

**Ítem 2 — bug de MIA no responde:** causa real encontrada siguiendo los 3 pasos ya documentados (no fue el paso 1 ni el 2 — ambos se revisaron y estaban bien armados). **El bug estaba en el paso 3:** `armarRespuesta()` (`respuestas.ts`) devolvía `null` cuando faltaba un dato del contexto (ej. `contexto.hoy` no llegó), y `procesarTurnoConversacion()` (`conversacion.ts`) solo mira si `respuesta` es truthy para decidir si ya resolvió por regla — un `null` ahí lo hacía caer al proxy de IA (stub sin proveedor configurado → 503), **incluso cuando el Intent Router SÍ había reconocido la pregunta correctamente.** Fix: `armarRespuesta` ya nunca devuelve `null` para una intención reconocida por regla — si falta el dato, devuelve un aviso hablable ("todavía no tengo tus datos de hoy cargados...") en vez de silencio. Verificado con `node` (simulación del flujo completo): con el bug, una pregunta reconocida pero sin contexto caía a "IA (503)"; con el fix, la misma pregunta responde por regla, con o sin datos.

**Honestidad sobre lo que NO quedó 100% cerrado en el ítem 2:** con datos reales (`contexto.hoy` con 5 viajes) el código YA funcionaba bien tanto antes como después del fix — la regla resolvía la respuesta directo. Esto significa que el fix garantiza que el error de "IA no configurada" nunca más va a aparecer para una pregunta que el router reconoce, pero **no se confirmó con certeza absoluta que `contexto.hoy` estuviera llegando vacío en la prueba real del usuario** (se revisó `ConversacionScreen.tsx` y el armado de `contexto` se ve correcto, sin ningún bug adicional encontrado ahí). Si el usuario vuelve a ver el mismo error tras este fix, el siguiente sospechoso sería una condición de carrera (toca el micrófono antes de que `cargarViajes()` termine) — no investigado en este corte porque el fix de `armarRespuesta` ya elimina el síntoma reportado de raíz, sea cual sea la causa exacta de que falte el dato.

Antes de esto: **📋 Se aclaró la estructura de paneles del rediseño (todavía sin tocar código).** El usuario precisó que Mantenimiento (recordatorio de servicio) y Gastos de jornada (costo por km, que varía cada período) tienen que quedar visualmente integrados dentro del MISMO panel de trabajo junto con Viajes/Jornada/Estadísticas — "toda la zona de trabajo de Uber en un solo panel, no en seis o siete". Quedaron aclaradas dos cosas: (1) por qué Mantenimiento y Gastos siguen siendo dominios separados aunque compartan pantalla (uno es recordatorio determinístico por km/fecha, el otro es una cifra que cambia cada período según cuánto se gastó y cuánto se recorrió — el propio usuario dio el ejemplo numérico); (2) la estructura final de paneles queda alineada con la que el usuario ya conocía de NOAH: Panel "Trabajo" (todo lo operativo, con secciones internas) + Panel "Casa y Deudas" (Hogar/Deudas/Ahorro) + Panel "Balance" + MIA como burbuja flotante (no un panel). Se actualizó el punto 11 del Bloque 4 del plan de trabajo para reflejar esto — ver "🆕 Pendiente nuevo — Diseño visual + expansión funcional". El orden de bloques (1 bugs → 2 funciones → 3 dominios nuevos → 4 visual) sigue igual. **Nota importante para cualquier sesión futura: Claude no tiene memoria entre conversaciones — solo existe lo que quede efectivamente dentro del zip.** Antes de cerrar cualquier sesión, hay que verificar que TODO archivo mencionado como "creado en esta sesión" esté de verdad incluido en el zip final que se entrega, no solo descrito en este documento.

Antes de esto: **✅ RESUELTO — "Crear cuenta" ya funciona en el dispositivo real.** Las dos causas (CORS mal configurado + `VITE_API_URL` apuntando a una URL de Render inexistente, y de paso un typo de sintaxis YAML — `VITE_API_URL:https://...` sin espacio tras los dos puntos — al corregir la segunda) quedaron corregidas y confirmadas. El registro de cuenta funciona, aunque el usuario nota que tarda ("le cuesta harto ingresar, como pensando") — normal en el plan free de Render, que apaga la instancia con inactividad y tarda ~50s en la primera respuesta después de estar dormida (ver aviso del propio dashboard de Render); no es un bug, no confirmado si vale la pena resolverlo ahora (ver "Qué falta decidir" o considerar plan pago de Render más adelante). **Tres pedidos nuevos del usuario en esta sesión, sin empezar — ver secciones nuevas más abajo:** (1) login con Google, con un requisito de UX específico: debe verse ANTES de entrar a la app, apenas se abre por primera vez — no un botón escondido dentro de la pantalla de Cuenta a la que hay que navegar; (2) un bug/gap en el asistente de voz (MIA): preguntas que el Intent Router de Fase 8 ya sabe responder sin IA (ej. "cuántos viajes hice hoy") están devolviendo el error de "IA no configurada" en vez de la respuesta armada — hay que investigar por qué; (3) el usuario pide poner el foco ahora en el diseño visual de la app completa (dice explícitamente que la interfaz actual "es una mierda") — no quiere esperar a la Fase 14 para esto.

Antes de esto: **Causa real de "Failed to fetch" confirmada con el diagnóstico en pantalla: NO era (solo) CORS — era `VITE_API_URL` apuntando a una URL de Render que no existe.** El workflow de GitHub Actions compiló el APK con `VITE_API_URL=https://mia-backend.onrender.com`, pero el servicio real en Render quedó como `https://mia-backend-kqms.onrender.com` (Render le agregó el sufijo `-kqms` porque el nombre simple ya estaba tomado — exactamente el riesgo que este mismo documento ya había anotado en la sección "Despliegue — Render + Neon"). El fix de CORS de la actualización anterior seguía siendo necesario y correcto, pero no alcanzaba por sí solo porque la app ni siquiera llegaba a intentar tocar el dominio correcto. **Pendiente — el usuario tiene que corregir a mano `.github/workflows/build-apk.yml`** (ese archivo no viaja dentro de este zip, se edita directo en github.com, ver "El usuario no tiene PC" más abajo): cambiar la línea `VITE_API_URL=https://mia-backend.onrender.com` a `VITE_API_URL=https://mia-backend-kqms.onrender.com`, volver a correr el workflow, instalar el APK nuevo y probar. **No confirmado todavía que esto resuelva el error del todo** — puede que haga falta el fix de CORS de la actualización anterior en simultáneo (ambos apuntaban al mismo síntoma en pantalla, `Failed to fetch`, pero son dos causas independientes). Antes de esto: **El fix de CORS (`CORS_ORIGENES`) ya se aplicó en Render y el backend está confirmado `Live` y respondiendo, pero "Crear cuenta" TODAVÍA daba `Failed to fetch`** — se agregó diagnóstico temporal en pantalla (URL exacta + estado de internet) porque el usuario no tiene forma de usar `chrome://inspect` desde una PC — **este diagnóstico es el que permitió encontrar la causa real de arriba, dejarlo en el código hasta confirmar que todo funciona.** Antes de esto: **Encontrado y corregido el bug de CORS que causaba "Failed to fetch" al tocar "Crear cuenta" en el dispositivo real**. Antes de esto: **Primera prueba real en dispositivo Android físico** — el deploy en Render funcionó (encontró la migración) y el APK se instaló y corre. Resultado de la prueba del pendiente crítico de Fase 5: el registro del plugin (sesión anterior) NO fue la causa completa — el permiso de ubicación sigue sin pedirse solo, el usuario lo concedió a mano. Se encontró una causa adicional probable en `domain/viajes/store.ts` (falta try/catch alrededor de `iniciarSeguimientoGPS`, así que un posible error ahí queda en silencio) — ver "Pendiente crítico arrastrado de Fase 5" para el detalle completo y los próximos pasos. Todavía no se aplicó el fix de manejo de errores, el usuario prefirió seguir probando otras pantallas primero con el permiso ya concedido a mano. Antes de esto: continuación con jornadas y registros de mantenimiento sincronizándose (mismo diseño push-only + upsert por id que viajes, D-16). Los ítems de mantenimiento (configuración editable/borrable) siguen sin sincronizar, a propósito — ver "Estado real de Fase 13" para el porqué completo. Jornada, que era la única excepción al patrón de D-8 (persistencia suelta dentro de `store.ts`, sin `repository.ts`), ahora tiene su `repository.ts` real. Antes de esto: Fase 13 arrancada — EN CURSO, solo viajes. Push-only, un viaje por request (`POST /sync/viajes`), dedupe real por `id` (upsert) + verificación de que ese `id` no pertenezca a otro usuario (403 si pasa). Esto también obligó a revisar el límite de body de Fase 12 (256kb → 512kb, documentado en `index.ts` por qué). Antes de esto: Fase 12 (Seguridad) — los pendientes #4 (logging de eventos de seguridad, `server/src/lib/logSeguridad.ts`, conectado a rate limit y a login/registro fallidos) y #5 (límite explícito de body) quedaron cerrados esa sesión. Antes de esto: Fase 11 (Google Play Billing) arrancada — EN CURSO, bloqueada en la práctica por no existir todavía una cuenta de desarrollador de Google Play (ver D-14 y "Estado real de Fase 11"). Antes: continuación de Fase 10 — pantalla de login/registro del cliente (`CuentaScreen.tsx`) construida (D-13), cerrando el pendiente #4 de Fase 7. Antes de eso: Fase 10 (voz + conversación continua) arrancada — EN CURSO, primera conexión real cliente↔backend (D-11). Antes: Fase 9 (IA analista) HECHA con salvedades (proveedor de IA real sigue sin decidirse). Antes de eso, Fase 5 (GPS en segundo plano): causa probable del permiso que nunca se disparó, corrección aplicada en `MainActivity.java`, **pero sigue sin confirmarse en un dispositivo real**. Fase 7 sigue EN CURSO (backend sin probar; cliente con login). Fase 6 con el código escrito, sin probar. **Nota importante para cualquier sesión futura: Claude no tiene memoria entre conversaciones — solo existe lo que quede efectivamente dentro del zip.** Antes de cerrar cualquier sesión, hay que verificar que TODO archivo mencionado como "creado en esta sesión" esté de verdad incluido en el zip final que se entrega, no solo descrito en este documento.

---

## Cómo continuar en una sesión nueva

1. Descomprime el zip que te entregaron junto con este archivo.
2. Lee la sección "Estado actual" (abajo) para saber exactamente dónde quedamos.
3. Lee "Decisiones tomadas" para no repreguntar cosas ya resueltas.
4. Sigue con la fase marcada como `EN CURSO` o la siguiente `PENDIENTE`.
5. Al cerrar la sesión (o cuando el usuario avise que se acaba el límite): actualiza este archivo (estado + decisiones nuevas) y entrega un zip nuevo con el código avanzado.

---

## Fases (documento de requisitos del usuario → 14 fases originales, reorganizadas en fases de trabajo reales)

| # | Fase | Estado | Entregable |
|---|---|---|---|
| 1 | Auditoría del proyecto viejo (NOAH Conductor) | ✅ HECHA | Hallazgos: pantallas huérfanas, CSS parchado, código muerto — documentados en el historial de conversación |
| 2 | Arquitectura limpia (cliente + backend + fuente única de verdad por responsabilidad) | ✅ HECHA | `docs/FASE2-ARQUITECTURA.md` (incluido en este proyecto) |
| 3 | Elegir stack técnico del proyecto nuevo, desde cero | ✅ HECHA | Decisiones D-1 a D-8 |
| 4 | Reconstruir el núcleo: dominio de viajes (GPS en primer plano, km reales, plataforma, jornada) | ✅ HECHA | `app/src/domain/viajes/`, `app/src/domain/jornada/` |
| 5 | GPS en segundo plano (foreground service nativo) + zonas/geofencing local | 🟡 EN CURSO | `app/android/.../gps/` (servicio + plugin), `app/src/domain/viajes/gpsBackground.ts`, `app/src/domain/viajes/geofencing.ts` — código escrito, sin integrar ni probar (ver "Estado real de Fase 5" abajo) |
| 6 | Mantenimiento + estadísticas | 🟡 EN CURSO (código escrito, sin probar) | `app/src/domain/mantenimiento/`, `app/src/domain/estadisticas/`, `app/src/features/mantenimiento/`, `app/src/features/estadisticas/` — ver "Estado real de Fase 6" abajo |
| 7 | Backend: auth + usuarios + planes | 🟡 EN CURSO (backend escrito, sin probar; cliente ahora tiene pantalla de login/registro, ver Fase 10) | `server/src/modules/auth`, `server/src/modules/plans`, `server/prisma/schema.prisma`, `app/src/domain/auth/`, `app/src/features/auth/CuentaScreen.tsx` — ver "Estado real de Fase 7" abajo |
| 8 | Intent Router (reglas + clasificador) | ✅ HECHA (con salvedades — ver "Estado real de Fase 8" abajo) | `server/src/modules/ai` |
| 9 | IA analista (proxy + contexto compacto) | ✅ HECHA (con salvedades — ver "Estado real de Fase 9" abajo) | `server/src/modules/ai` (analisis.ts, contextoCompacto.ts, proveedorIA.ts) |
| 10 | Voz + conversación continua | 🟡 EN CURSO (código escrito, sin probar) | `server/src/modules/ai/conversacion.ts` (+ ruta `POST /ai/conversacion`), `app/src/domain/conversacion/`, `app/src/features/conversacion/ConversacionScreen.tsx`, `app/src/lib/api.ts` — ver "Estado real de Fase 10" abajo |
| 11 | Google Play Billing (planes) + validación server-side | 🟡 EN CURSO (código escrito, sin probar) | `server/src/modules/billing/`, catálogo de planes ampliado en `server/src/modules/plans/`, `app/src/domain/planes/`, `app/src/features/planes/PlanesScreen.tsx` — ver "Estado real de Fase 11" abajo |
| 12 | Seguridad (auth, rate limits, datos por usuario) | 🟡 EN CURSO — lo que faltaba de código ya está (logging + límite de body); lo que queda está bloqueado por red/despliegue, no por código | `server/src/http/rateLimit.ts`, `server/src/lib/logSeguridad.ts`, `cors`/`helmet` en `index.ts`, `env.corsOrigenes` — ver "Estado real de Fase 12" abajo |
| 13 | Offline + sincronización con dedupe | 🟡 EN CURSO — viajes, jornadas y registros de mantenimiento (ítems de mantenimiento a propósito afuera, ver "Estado real de Fase 13") | `server/src/modules/sync/`, `app/src/domain/{viajes,jornada,mantenimiento}/{api,sync}.ts`, `app/src/domain/jornada/repository.ts` (nuevo) |
| 14 | Pruebas completas + limpieza final + preparación para Google Play (Data Safety, permisos, target API) | ⬜ PENDIENTE | — |

---

## Decisiones tomadas (no volver a preguntar esto)

- **D-1 — Plugins nativos de Android (burbuja, alarma):** se reutilizan tal cual del proyecto viejo, sin reescribir. Es la única excepción a "todo se construye desde cero", justificada porque ya usan las APIs correctas de Android. Package original `com.noah.conductor.atlas.*` se mantiene por ahora para no generar trabajo extra de renombrado; se puede renombrar a `com.mia.*` en la Fase 14 (limpieza final) sin riesgo, es un cambio mecánico.
- **D-2 — Stack cliente:** Capacitor + React + TypeScript + Tailwind. Se re-eligió (no se heredó) porque sigue siendo la opción correcta para una app híbrida Android con necesidad de plugins nativos propios.
- **D-3 — Estado del cliente:** Zustand, pero **un store por dominio** (viajes, gastos, deudas, mantenimiento...), cada uno con su propia cola de sincronización — no un store monolítico como en el proyecto viejo.
- **D-4 — Stack backend:** Node.js + TypeScript + Express + PostgreSQL + Prisma. Elegido por ser estándar, sin vendor lock-in, fácil de mantener y con soporte amplio para desplegar donde sea.
- **D-5 — Auth inicial:** JWT propio (email + contraseña) para arrancar. Login con Google se puede agregar después sin romper nada, porque el backend ya abstrae "usuario autenticado" detrás de un middleware único.
- **D-6 — Pagos:** Google Play Billing Library en el cliente + endpoint en el backend que valida el recibo contra la API de Google (Play Developer API). Ninguna pasarela de pago propia para las mensualidades — es requisito de Google para contenido digital.
- **D-7 — Geolocalización de zonas:** motor local con polígonos embebidos en el cliente (sin API externa por viaje). **Resuelto en Fase 5:** las 20 localidades oficiales de Bogotá, tomadas del dataset "Localidad. Bogotá D.C." de Datos Abiertos Bogotá (Catastro Distrital), simplificadas con Douglas-Peucker (~40m de tolerancia, de 57.840 vértices originales a ~2.000) y cargadas en `app/src/domain/viajes/zonasBogota.ts`. Si la cobertura se extiende a otras ciudades más adelante, se agrega como otro archivo de zonas y se decide ahí cómo combinarlos — no es parte del alcance actual.
- **D-9 — GPS solo funciona en primer plano todavía (gap real, no ignorar):** `domain/viajes/gps.ts` usa `@capacitor/geolocation`, que deja de capturar recorrido si la app se minimiza o la pantalla se apaga. Para un conductor esto es inaceptable — el viaje puede durar con el teléfono guardado. La solución es un plugin nativo de Android nuevo, con un foreground service de tipo `location` (mismo patrón que `burbuja`/`alarma`, que si funcionan en esas condiciones). Este plugin **no existe todavía**. Es la prioridad #1 de la Fase 5, antes que las zonas/geofencing.
- **D-10 — Jornada es un dominio separado de viajes:** `domain/jornada/` solo agrupa IDs de viajes de un turno; no duplica ni recalcula nada de `domain/viajes`. La conexión entre los dos (agregar un viaje recién terminado a la jornada abierta) se hace en la capa de orquestación (`features/viajes/ViajesScreen.tsx`), nunca dentro de los stores — así ningún store depende de otro.
- **D-11 — Conexión cliente↔backend y conversación (Fase 10):** `/ai/conversacion` NO persiste nada en el backend — el cliente manda `turnosPrevios` (los últimos turnos de ESTA conversación de voz) en cada request, mismo principio que D-8/Fase 8 ("el cliente manda el dato ya calculado, el backend no es dueño de datos que no le corresponden todavía"). Esto también obligó a crear `app/src/lib/api.ts`, la primera vez que `app/` llama de verdad a `server/` (antes de esto, Fase 7 punto 4 lo dejaba pendiente para Fase 13/sync). El cliente guarda los tokens en `localStorage` (`lib/api.ts`) — inicialmente esto se escribió sin que existiera ninguna pantalla que llamara a guardar el token; **eso se resolvió en la continuación de esta misma fase (ver D-13): ya existe `app/src/features/auth/CuentaScreen.tsx`.**
- **D-12 — Voz: plugins de Capacitor de la comunidad, no plugins nativos propios:** a diferencia del GPS en segundo plano (D-9, que sí necesitó un plugin Kotlin propio porque no hay alternativa para un foreground service de ubicación), el reconocimiento de voz y el texto a voz usan `@capacitor-community/speech-recognition` y `@capacitor-community/text-to-speech` — plugins ya existentes y mantenidos, agregados a `app/package.json`. Ninguno necesita foreground service: solo funcionan con la app en primer plano, que es exactamente el caso de uso (el conductor le habla a la app abierta). Por eso NO es una excepción a "todo se construye desde cero" en el sentido de D-1 (no se copió código del proyecto viejo NOAH Conductor, que además nunca tuvo esta función) — es simplemente usar una librería de terceros para algo que no justifica reinventar, igual que ya se usa `@capacitor/geolocation` como fallback web en `gps.ts`.
- **D-13 — Pantalla de login/registro (continuación de Fase 10, cierra pendiente #4 de Fase 7):** una sola pantalla (`CuentaScreen.tsx`) con un toggle login/registro en vez de dos separadas, porque el formulario es idéntico (email + contraseña) y el backend ya distingue el error de cada caso. La sesión se guarda como el par de tokens en `localStorage` (`lib/api.ts`, `guardarTokens`/`obtenerTokenAcceso`/`obtenerTokenRefresco`/`borrarTokens`) — `haySesion()` decide "¿sigo logueado?" mirando si hay token de acceso guardado, NO se valida contra el backend al abrir la app. Huecos conocidos, dejados así a propósito por alcance (no bloquean usar la pantalla, sí hay que resolverlos antes de publicar): (1) no hay refresco automático — si el token de acceso (dura pocos minutos, `JWT_EXPIRACION_ACCESO_MIN`) expira a mitad de una conversación, la llamada falla con 401 y hoy no se reintenta sola con el token de refresco, aunque éste ya se guarda; (2) el objeto `usuario` (nombre/email en memoria) NO se restaura al recargar la app — solo el token persiste, así que tras recargar `autenticado()` da `true` pero `usuario` es `null` hasta el próximo login; la corrección natural es llamar a `GET /auth/yo` al arrancar si hay token guardado, no se hizo en este corte.
- **D-14 — Billing: idempotencia por `purchaseToken`, sin flujo de compra falso en el cliente (Fase 11):** `PlanDeUsuario.purchaseToken` es único en la base — si `POST /billing/validar-compra` recibe un token que ya generó una fila, devuelve el plan que ya se activó SIN volver a llamar a Google ni duplicar nada (cubre reintentos del cliente). Activar un plan nuevo desactiva —no borra— los anteriores del usuario, para conservar historial. Del lado del cliente, `PlanesScreen.tsx` es **solo lectura** (plan actual + catálogo): no hay botón de "Comprar" que simule una compra, porque D-6 exige que cualquier cobro dentro de la app pase por Google Play Billing Library, y esa integración nativa no se escribió en este corte (ver "Estado real de Fase 11" — el bloqueante real es no tener todavía una cuenta de desarrollador de Google Play contra la cual probar nada de esto).
- **D-15 — Rate limiting propio en memoria, no un paquete (Fase 12):** `http/rateLimit.ts` es una ventana fija por IP escrita a mano (15 líneas), no `express-rate-limit`. Se verificó con `node` (bloquea al superar el máximo, se resetea pasada la ventana, cada IP tiene su propio contador). **Límite real, no ignorar:** vive en memoria del proceso — si el backend corre en más de una instancia, cada una cuenta por separado (el límite efectivo se multiplica por la cantidad de instancias). Migrar a un store compartido (Redis) si eso llega a pasar; no se adelantó sin necesidad confirmada. También se agregó `app.set('trust proxy', 1)` para que `req.ip` sea la IP real del cliente y no la del proxy — asumiendo un solo proxy delante (típico de Render/Railway/Heroku), sin poder confirmarlo contra un despliegue real todavía (sigue sin decidirse dónde se despliega, ver "Qué falta decidir").
- **D-16 — Sync push-only, un viaje por request, no un lote (Fase 13):** `POST /sync/viajes` recibe UN viaje, no un array. Se decidió así por dos razones juntas: (1) acota el tamaño del body al de un solo viaje, no al de "todo lo acumulado sin internet" — importante porque el `recorrido` (puntos GPS) es lo único de este backend que puede pesar de verdad, y un lote de un día entero sin sync sí podía chocar contra el límite de Fase 12; (2) hace el dedupe y el manejo de errores más simples: si algo falla a mitad de la cola, se sabe exactamente cuál viaje fue, sin tener que descomponer una respuesta parcial de un batch. El cliente (`domain/viajes/sync.ts`) recorre la cola local en secuencia, uno a la vez — no en paralelo, para no saturar el rate limiter de `/sync/viajes`. Es **push-only**: el backend no empuja cambios de vuelta al cliente (no hay sincronización multi-dispositivo) — no hay ningún requisito de "varios dispositivos" en el documento original de MIA, así que no se construyó sin necesidad confirmada.
- **D-8 — Convención de carpetas:** `app/` = cliente móvil, `server/` = backend, `docs/` = documentos de arquitectura y planeación. Cada módulo de dominio vive en `app/src/domain/<nombre>/` con `types.ts`, `repository.ts`, `store.ts` — ese es el patrón a repetir para cada nuevo módulo (gastos, deudas, mantenimiento, etc.), no inventar una estructura distinta por módulo.
- **D-17 — Despliegue: Render (backend) + Neon (Postgres), ambos plan free, elegidos explícitamente por el usuario por ser "lo más fácil ahora sin perder la salida después":** el criterio fue que D-4 (Node + Express + Postgres + Prisma) ya se había elegido por no tener nada propietario de un proveedor — así que cualquier combinación de hosting estándar sirve, y migrar después es `pg_dump`/`pg_restore` + cambiar `DATABASE_URL`, nada de reescribir código. Se prefirió Neon sobre el Postgres gratis de Render porque el de Render expira a los 30 días (hay que pagar o perder los datos); Neon es gratis sin fecha límite. Render se eligió para el backend en sí porque se conecta directo a GitHub desde el navegador (coherente con que el usuario no tiene PC).

---

- **D-18 — Regla explícita del usuario para el trabajo de expansión funcional + rediseño (esta sesión, aplica de acá en adelante para TODO el proyecto, no solo esta etapa):** nunca crear un archivo nuevo para "solucionar por fuera" un problema de uno que ya existe — eso fue literalmente lo que rompió el proyecto anterior con la otra IA (parches sobre parches hasta tener que empezar de cero). La regla concreta: (1) si algo tiene un bug, se corrige el archivo donde está el bug, nunca se envuelve con una capa nueva al lado; (2) si una función ya existe y sirve (aunque sea parcialmente) para lo que se necesita, se reutiliza o se extiende esa misma función — no se crea una segunda versión con otro nombre "por las dudas"; (3) un dominio nuevo (`gastos`, `deudas`, `hogar`) se agrega siguiendo el patrón D-8 ya establecido, no un patrón distinto por conveniencia del momento; (4) antes de escribir cualquier línea de código nuevo, confirmar primero qué ya existe (este documento + una lectura real del archivo) — no asumir que algo no existe sin haberlo revisado. Ver el diagnóstico completo hecho bajo esta regla en "🆕 Pendiente nuevo — Diseño visual + expansión funcional".

## Qué falta decidir (preguntar al usuario cuando se llegue a esa fase, no antes)

- Proveedor de IA definitivo para el proxy del backend — aplica tanto al clasificador de respaldo de Fase 8 como al proxy de análisis de Fase 9 (mismo tipo de pieza en ambos: `(entrada) => Promise<resultado>`, inyectable, sin implementación real todavía).
- Dónde se despliega el backend (Fase 7 en adelante) — ✅ RESUELTO esta sesión: Render (web service, plan free) + Neon (Postgres, plan free permanente — a diferencia del Postgres gratis de Render, que expira a los 30 días). Ver D-17 y "Despliegue — Render + Neon" más abajo.
- Set de ciudades/zonas a cubrir en el geofencing local (Fase 5). ✅ RESUELTO — 20 localidades de Bogotá, ver D-7.
- Nombre final de paquete Android / branding (`com.mia.conductor` u otro) — no urge, se resuelve en Fase 14. **Fase 11 ya empezó a depender de esto**: `packageName` es uno de los tres datos que `POST /billing/validar-compra` le manda a Google para verificar una compra — si el paquete final termina siendo otro, no rompe el código (es un parámetro, no algo hardcodeado), pero si urge más de lo que se pensaba porque también hay que crear la app en Play Console con ese mismo nombre antes de poder configurar ningún producto.
- Cuenta de desarrollador de Google Play — todavía no existe (o al menos, no se confirmó que exista). Sin ella no hay Play Console, y sin Play Console no se puede: (a) crear el producto/suscripción real que `PLANES_BASE.pro_mensual.productIdGooglePlay` (`'mia_pro_mensual'`, ver `modules/plans/types.ts`) asume que va a existir, (b) generar la cuenta de servicio que necesita `modules/billing/googlePlay.ts` para verificar compras, ni (c) probar nada de Fase 11 de punta a punta. Es, en la práctica, EL bloqueante de Fase 11 — no un detalle de "Qué falta decidir" tardío.
- Precio del plan `pro_mensual` (y si hace falta más de un plan pago) — no se inventó un precio porque fijarlo es una decisión de negocio, no técnica.

## Estado real de Fase 5 (para la próxima sesión)

Hecho hasta ahora:

1. **Plugin nativo Kotlin** en `app/android/app/src/main/java/com/noah/conductor/atlas/gps/`:
   - `GpsTrackingService.kt` — foreground service tipo `location`, usa `FusedLocationProviderClient`, notificación persistente con botón "Detener", `START_STICKY`.
   - `GpsTrackingPlugin.kt` — puente Capacitor (`GpsTracking.startTracking()` / `.stopTracking()` / `addListener('locationUpdate', ...)`), maneja el flujo de permisos de foreground y background location por separado (requisito de Android 10+).
2. **Wrapper TS** `app/src/domain/viajes/gpsBackground.ts` — llama al plugin nativo.
3. **`domain/viajes/gps.ts` ya integrado**: `iniciarSeguimientoGPS` detecta si corre en Android nativo (`Capacitor.isNativePlatform() && getPlatform() === 'android'`) y en ese caso delega en el foreground service; si no (navegador/dev web), cae a `@capacitor/geolocation` como antes. La interfaz `SeguidorGPS` no cambió, así que **`store.ts` y `ViajesScreen.tsx` no se tocaron** — el patrón de Fase 4 sigue intacto.
4. **Motor de geofencing** `app/src/domain/viajes/geofencing.ts` + `app/src/domain/viajes/zonasBogota.ts` — `obtenerZona(punto, zonas)` con ray casting sobre polígonos, soporta zonas con más de un anillo (Santa Fe tiene 2 partes separadas en la fuente oficial). **`ZONAS` ya no está vacío**: son las 20 localidades reales de Bogotá (D-7 resuelto), verificadas contra puntos conocidos (aeropuerto El Dorado → Fontibón, Corabastos → Kennedy, un punto en Chía → `null`).
5. **`repository.ts` ya conectado**: `crearViajeDesdeCiere` resuelve `localidad`/`zona` contra el último punto del recorrido usando `obtenerZona`. Ambos campos reciben el mismo valor por ahora (el motor no distingue "localidad" de "zona" como capas separadas todavía — ver comentario en el código).
6. `docs/FASE5-GPS-MANIFEST.md` — permisos y declaración de servicio que hay que agregar a mano en `AndroidManifest.xml` (no venía en este zip).

Hecho en esta sesión (continuación de Fase 5, punto pendiente #1 de la sesión anterior):

7. **Proyecto Capacitor Android armado desde cero** — no existía ningún archivo de proyecto real, se escribieron a mano (sin poder correr `npx cap add android` porque este entorno no tiene red ni `node_modules` instalados):
   - `app/capacitor.config.ts` — `appId: com.noah.conductor.atlas` (D-1: se mantiene el package viejo, renombrar es tarea de Fase 14).
   - `app/android/build.gradle`, `settings.gradle`, `variables.gradle`, `gradle.properties` — proyecto Gradle raíz.
   - `app/android/app/build.gradle` — módulo `app`, **ya con la dependencia `play-services-location` aplicada** (punto 4 de `docs/FASE5-GPS-MANIFEST.md`).
   - `app/android/app/src/main/AndroidManifest.xml` — **con los permisos y el `<service>` de `GpsTrackingService` de `docs/FASE5-GPS-MANIFEST.md` ya aplicados**, más lo que ya necesitaban los plugins viejos (`BurbujaService` con `foregroundServiceType="specialUse"` porque llama `startForeground()` y con targetSdk 35 eso es obligatorio; `AlarmaActivity` con `showWhenLocked`/`turnScreenOn` según el comentario del propio `.kt`).
   - `MainActivity.java` (extiende `BridgeActivity`, sin `registerPlugin()` manual — Capacitor 3+ detecta los `@CapacitorPlugin` solo).
   - Recursos mínimos: `strings.xml`, `colors.xml`, `styles.xml` (tema `Theme.SplashScreen`), `file_paths.xml`, e iconos placeholder (círculo, todas las densidades) — **hay que reemplazarlos por el icono real antes de publicar, no antes**.
   - `app/android/capacitor-cordova-android-plugins/` — módulo vacío que Capacitor espera aunque no haya plugins Cordova.

   **Lo que NO se pudo hacer por no tener red/Android SDK en este entorno** (queda para la próxima sesión, con el proyecto real):
   - No se corrió `npm install` ni `npx cap sync android` — `settings.gradle` apunta a `node_modules/@capacitor/...` que todavía no existen en este zip. Al correr `cap sync` con las dependencias instaladas, Capacitor regenerará `app/android/app/capacitor.build.gradle` (aquí quedó un placeholder mínimo) y puede ajustar rutas.
   - Falta el **wrapper de Gradle** (`gradlew`, `gradlew.bat`, `gradle-wrapper.jar`) — solo se dejó `gradle-wrapper.properties`. Android Studio lo regenera solo al abrir el proyecto y sincronizar, o se genera con `gradle wrapper` si hay un Gradle local instalado.
   - No se compiló ni se probó nada — sin Android SDK/emulador/dispositivo en este entorno es imposible. **Sigue siendo tarea del usuario** compilar y probar en un teléfono físico (el emulador no sirve para GPS en segundo plano de forma confiable).

Pendiente para cerrar la Fase 5 (en orden):

1. Push del repo a GitHub (no hace falta PC — se puede crear el repo y subir los archivos desde el navegador/celular) para que corra `.github/workflows/build-apk.yml`.
2. Descargar el APK generado (artefacto del workflow) e instalarlo en un Android físico.
3. Probar en ese dispositivo — verificar que el recorrido se siga grabando con la app minimizada y la pantalla apagada. Esto no se puede mover a la nube, necesita un teléfono real.
4. Reemplazar los iconos placeholder por los definitivos (no urgente, antes de publicar).
5. Decidir si `localidad` y `zona` deben ser dos lookups distintos o si el valor único actual es suficiente (no urgente).
6. No se tocó `domain/jornada` en ningún momento de la Fase 5.

## El usuario no tiene PC — no puede usar Android Studio (aclarado en esta sesión)

Se agregó `.github/workflows/build-apk.yml` — un flujo de GitHub Actions que compila el APK en la nube. **Ajustado en esta misma sesión** porque GitHub, desde el navegador de un celular, no deja subir una carpeta completa ni descomprime zips subidos — solo deja elegir archivos sueltos. Solución: el workflow ahora **descomprime el zip él mismo** (`unzip -o mia-proyecto.zip -d .` como primer paso). Así el usuario solo sube dos archivos sueltos a la raíz del repo, nunca carpeta por carpeta:
1. `.github/workflows/build-apk.yml` — se crea con "Add file → Create new file" en github.com, escribiendo la ruta completa con barras en el campo de nombre (GitHub crea las carpetas solo).
2. `mia-proyecto.zip` — el zip del proyecto tal cual, sin descomprimir, subido con "Add file → Upload files" (selecciona un solo archivo, sin arrastrar carpetas).

Después: `npm install` → `npm run build` (vite) → `npx cap sync android` → `gradle wrapper` (genera `gradlew`, que este proyecto armado a mano nunca tuvo) → `./gradlew assembleDebug`. El APK queda descargable como artefacto del workflow.

De paso, revisando por qué el build web podía fallar, se encontró que **faltaban archivos base del cliente que ninguna fase anterior había creado** (no es un pendiente que estuviera escrito en este plan, es un hueco real): `index.html`, `src/main.tsx`, `src/App.tsx`, `vite.config.ts`, `tsconfig.json`/`tsconfig.app.json`/`tsconfig.node.json`. Se crearon todos en esta sesión — `App.tsx` monta `ViajesScreen` (único feature construido hasta ahora); cuando arranque Fase 6 y haga falta navegación entre pantallas, ahí se agrega `react-router-dom` (ya está en `package.json`, sin usar todavía).

**No se pudo verificar que el build realmente compile** — este entorno no tiene acceso a red (falla `npm install` con 403 al registry) ni Android SDK, así que ninguno de estos archivos nuevos se probó de punta a punta. La primera corrida del workflow en GitHub Actions es, en los hechos, la primera vez que se prueba esta cadena completa. Si falla, el log de esa corrida (pestaña Actions en github.com) dice exactamente en qué paso y por qué.

---

## ⚠️ Pendiente crítico arrastrado de Fase 5 — PROBADO EN DISPOSITIVO REAL: el registro del plugin NO fue la causa completa, sigue sin pedirse el permiso solo

**✅ Ítem 1 de "sigue pendiente" (abajo) — RESUELTO en el Bloque 1 de esta sesión:** se agregó el try/catch visible alrededor de `iniciarSeguimientoGPS` en `store.ts` que este documento pedía como prioridad #1. Ahora, si el GPS falla al iniciar un viaje, el viaje en curso se cancela (ya no se ve "iniciado" con el GPS realmente caído) y el error queda expuesto en `errorGPS` del store, mostrado en `ViajesScreen.tsx`. **Los ítems 2-5 de "sigue pendiente" siguen sin poder hacerse desde acá — requieren volver a probar en el dispositivo real del usuario** (esta sesión no tiene forma de compilar el APK ni acceder a un teléfono).

Al probar el APK en casa, el sistema nunca pidió el permiso de ubicación — ni el de primer plano ni el de segundo plano.

**Primer candidato investigado (sesión anterior):** `MainActivity.java` no registraba manualmente los plugins nativos propios. Se corrigió (`registerPlugin()` en `onCreate()`), se compiló un APK nuevo, y **esta vez sí se probó en un dispositivo Android real — el permiso SIGUE sin pedirse solo**. El usuario tuvo que concederlo a mano desde Ajustes del sistema. Conclusión: el registro del plugin era necesario (sin él, nada del plugin funciona), pero **no era la causa completa** — o hay una causa adicional, o directamente otra distinta.

**Segundo candidato, encontrado revisando `domain/viajes/store.ts` (ahora SÍ corregido, ver arriba):** en `iniciarViaje()`, la llamada `seguidorActivo = await iniciarSeguimientoGPS(...)` **no estaba envuelta en try/catch**, y el estado `viajeEnCurso` se ponía ANTES de esa llamada — así que si `iniciarSeguimientoGPS` (que termina llamando a `GpsTracking.startTracking()`, la que debería disparar el diálogo de permiso) fallaba o lanzaba un error en cualquier punto de la cadena, la UI de todos modos mostraba el viaje como iniciado (coincide con la captura de pantalla: "Uber 0.0 km reales $20.000" apareció igual). Es decir: **es muy posible que el error SÍ esté pasando, pero nadie lo veía** — ni el usuario, ni nosotros, porque no había ningún catch que lo mostrara en pantalla ni lo logueara. **Esto ya se corrigió (Bloque 1) — la próxima prueba en dispositivo real debería decir exactamente qué está fallando, si algo sigue fallando.**

**Corrección aplicada (Bloque 1, esta sesión):** try/catch visible alrededor de `iniciarSeguimientoGPS` en `store.ts` — ver arriba.

**Sigue pendiente, en orden (ahora empieza en el punto 2, el punto 1 ya se hizo):**

1. ~~Agregar manejo de errores visible alrededor de `iniciarSeguimientoGPS` en `store.ts`~~ — **HECHO en el Bloque 1.**
2. Con eso compilado, repetir la prueba: iniciar un viaje SIN haber dado el permiso manualmente antes, y ver si ahora aparece un mensaje de error visible (que diría exactamente dónde falla) en vez de silencio total.
3. Si el error señala el permiso en sí (ej. "Permiso de ubicación denegado" del `call.reject` en `GpsTrackingPlugin.kt`), hay que revisar por qué `requestPermissionForAlias` no dispara el diálogo del sistema — ahí sí puede seguir siendo necesario mirar la pantalla de "divulgación destacada" que exige Google antes de `ACCESS_BACKGROUND_LOCATION` (candidato #3, sin descartar).
4. Confirmar si `Burbuja`/`AlarmaPantalla` tienen el mismo problema (comparten el registro del plugin que sí se corrigió, pero no se sabe si tienen el mismo patrón de error silencioso del lado TS).
5. Con el permiso ya concedido a mano (como está ahora en el dispositivo del usuario), sí se puede probar mientras tanto si el foreground service de GPS en sí funciona correctamente en segundo plano — eso no depende de que el diálogo aparezca solo, solo de que el permiso esté concedido de algún modo. Es la prueba que el usuario va a hacer ahora mismo.

## ⚠️ Bug encontrado y corregido — "Failed to fetch" al crear cuenta (CORS mal configurado en Render)

Al probar `CuentaScreen.tsx` en el dispositivo real (primera vez que Fase 7/10 se prueba de punta a punta contra el backend desplegado), tocar "Crear cuenta" mostró en pantalla el texto crudo `Failed to fetch`. Eso es el mensaje nativo de un error de red de `fetch()` en el navegador/WebView — **no** es un error que venga del backend: si el backend hubiera respondido (aunque fuera con un error), `procesarRespuesta()` en `app/src/lib/api.ts` lo habría convertido en un `ErrorApi` con otro mensaje (`Error del backend (500)`, etc.). Que se vea literalmente `Failed to fetch` significa que la petición nunca llegó a completarse a nivel de red.

**Causa encontrada:** `render.yaml` configuraba `CORS_ORIGENES=capacitor://localhost,http://localhost`, con un comentario que asumía que `capacitor://localhost` es el origen que usa la app Android empaquetada. **Eso está al revés:** `capacitor://localhost` es el esquema por defecto de Capacitor en **iOS**; en **Android**, desde Capacitor 3, el esquema por defecto es `https://localhost` (se puede cambiar declarando `server.androidScheme` en `capacitor.config.ts`, y este proyecto no lo declara — así que usa el default). Como `https://localhost` nunca estuvo en la lista de orígenes permitidos, el propio WebView bloquea el preflight CORS de cualquier `fetch()` con `POST` + `Content-Type: application/json` (registro, login) antes de que la respuesta llegue a JavaScript — eso es exactamente lo que produce `TypeError: Failed to fetch`, sin más detalle en pantalla.

**Corregido en esta sesión:**
- `render.yaml` — `CORS_ORIGENES` ahora es `capacitor://localhost,http://localhost,https://localhost` (se dejan los tres: el nuevo cubre Android real, los otros dos quedan por si el esquema cambia o se corre en iOS más adelante).
- `server/src/config/env.ts` — el valor por defecto de `corsOrigenes` (el que se usa en desarrollo local si no hay `CORS_ORIGENES` en el entorno) también incluye ahora `https://localhost`.

**Pendiente para que el fix tenga efecto real — esto lo tiene que hacer el usuario, no es solo código:**

1. Actualizar la variable `CORS_ORIGENES` en Render (dashboard → el servicio → Environment) al valor nuevo. **Ojo:** Render normalmente no pisa una env var que ya fue seteada a mano solo porque `render.yaml` cambió en el repo — puede hacer falta editarla directamente ahí, no alcanza con que el código nuevo se suba.
2. Redesplegar el backend (o esperar a que Render lo haga solo al detectar el push, según cómo esté configurado el auto-deploy).
3. Repetir la prueba de "Crear cuenta" en el teléfono. Si el problema era solo este, ya debería funcionar.
4. **Si sigue fallando con el mismo `Failed to fetch` después del punto 3:** el siguiente sospechoso es `VITE_API_URL` mal inyectado en el build de este APK específico — `app/src/lib/api.ts` cae a `http://localhost:3000` si esa variable no llegó al build, y esa dirección no existe en el teléfono (sería otro `Failed to fetch`, indistinguible del de CORS solo mirando la pantalla). Para diferenciarlos hace falta ver la consola real del WebView (Chrome remoto: `chrome://inspect` con el teléfono conectado por USB y depuración habilitada) — el error de CORS y el de host inexistente se ven distinto ahí, aunque en pantalla midan igual.

**No se pudo verificar en este entorno** (sin red ni acceso a Render/Android reales) — el diagnóstico se hizo revisando el comportamiento documentado de `androidScheme` en Capacitor y confirmando en el código que `capacitor.config.ts` no lo declara, no ejecutando la app.

**Actualización — el fix de CORS solo no resolvió el error:** el usuario ya actualizó `CORS_ORIGENES` en Render, forzó un "Deploy latest commit" (no rollback), confirmó que el servicio está `Live`, y confirmó que el backend responde (`https://mia-backend-kqms.onrender.com/` devuelve `Cannot GET /`, o sea que el proceso está vivo). Aun así, "Crear cuenta" sigue mostrando `Failed to fetch`. El usuario no tiene forma de conectar el teléfono a una PC para leer la consola real del WebView (`chrome://inspect`), así que no se pudo confirmar si el problema real es el de CORS (podría no haberse resuelto por algo no evidente, ej. Render tardando en aplicar la env var, o un typo) o si es un segundo problema independiente (candidato principal: `VITE_API_URL` mal inyectado en el build de este APK, cayendo al default `http://localhost:3000`).

**Diagnóstico temporal agregado en el código (sesión actual), para no depender de una PC:**
- `app/src/lib/api.ts` — `URL_BASE` ahora se exporta (antes era privado del módulo).
- `app/src/domain/auth/store.ts` — `mensajeDeError()` ahora arma un mensaje más largo con: nombre y mensaje del error, la URL exacta a la que se intentó conectar (`URL_BASE`), y si el teléfono tenía internet en ese momento (`navigator.onLine`). Esto se muestra directo en la pantalla de "Crear cuenta"/"Iniciar sesión" (es el mismo `error` que ya se mostraba, solo que con más detalle).

**Esto es deliberadamente temporal** — ambos cambios están marcados con comentarios `TEMPORAL` en el código. Cuando el bug se confirme y resuelva, hay que revertir `mensajeDeError()` a su versión simple (una sola línea con `error.message`) y volver a hacer privado `URL_BASE` en `lib/api.ts` (quitarle el `export`).

**Siguiente paso (pendiente, requiere que el usuario recompile y pruebe):**
1. Subir este código actualizado (push a GitHub, correr el workflow del APK).
2. Instalar el APK nuevo y tocar "Crear cuenta" otra vez.
3. Leer el mensaje de error completo en pantalla (ahora va a decir a qué URL intentó conectarse) y reportarlo — con eso se sabe si el problema sigue siendo CORS (la URL sería la correcta, `https://mia-backend-kqms.onrender.com`, pero igual falla) o si es la URL mala (mostraría `http://localhost:3000`, confirmando que `VITE_API_URL` nunca llegó al build).

## ✅ RESUELTO — "Failed to fetch" al crear cuenta (confirmado por el usuario en dispositivo real)

Las dos correcciones de las secciones de arriba (CORS + `VITE_API_URL`, más el typo de sintaxis YAML del workflow que apareció al aplicar la segunda) resolvieron el problema. El usuario confirmó que "Crear cuenta" ya funciona. Queda pendiente, no urgente: quitar el diagnóstico temporal de `mensajeDeError()` en `app/src/domain/auth/store.ts` y el `export` de `URL_BASE` en `app/src/lib/api.ts` (ambos marcados `TEMPORAL` en el código) una vez que el usuario confirme que no va a necesitar ese detalle extra en pantalla para depurar algo más en el corto plazo — no se sacó todavía en esta sesión porque puede seguir sirviendo mientras se prueban las demás pantallas.

**Nota del usuario, no bloqueante:** el login/registro tarda notablemente ("como pensando") — es el comportamiento esperado del plan free de Render (la instancia se duerme con inactividad y tarda ~50 segundos en responder la primera vez que despierta, según el propio aviso del dashboard de Render). No se decidió todavía si vale la pena resolverlo (implicaría pasar a un plan pago de Render) — dejarlo anotado para cuando se revise el punto de "Qué falta decidir" o cuando el usuario lo priorice.

## 🆕 Pendiente nuevo — Login con Google, con requisito de UX específico

El usuario pidió agregar "iniciar sesión con Google" (ya estaba contemplado como posible en D-5: "Login con Google se puede agregar después sin romper nada, porque el backend ya abstrae 'usuario autenticado' detrás de un middleware único"). Lo nuevo de esta sesión es un **requisito de UX explícito, no solo la función**:

- La opción de iniciar sesión (incluyendo Google) tiene que aparecer **apenas se abre la app la primera vez, antes de entrar a cualquier otra pantalla** — no como un botón dentro de la pantalla `/cuenta` a la que hay que navegar desde la barra de abajo. El usuario fue explícito: "ese panel debe estar apenas salga, apenas descargue la aplicación y la instale, ingresar" — es decir, un flujo de bienvenida/login como puerta de entrada, no una pantalla más entre varias.
- No se decidió todavía (hay que confirmar con el usuario cuando se llegue a esta fase): si "apenas se abre" significa que un usuario sin cuenta directamente no puede tocar nada más de la app hasta loguearse (bloqueo total), o si algunas pantallas siguen siendo accesibles sin cuenta (hoy `ViajesScreen`, `MantenimientoScreen`, `EstadisticasScreen` no piden sesión, la única que la exige es `ConversacionScreen` — ver D-13). Cambiar esto es una decisión de producto, no solo técnica.

**Nada de esto se implementó todavía** — queda como pendiente para una próxima sesión: (1) decidir el alcance exacto de "pantalla de bienvenida/login obligatoria" arriba, (2) implementar el flujo de Google Sign-In en el cliente (librería nativa de Android — Credential Manager / Google Identity Services, no existe nada de esto en el proyecto hoy), (3) el backend en `modules/auth/` necesita una ruta nueva para validar el token de Google y crear/vincular el `Usuario` correspondiente (hoy solo sabe email+contraseña).

## 🆕 Pendiente nuevo — MIA (asistente de voz) no responde preguntas que ya podría resolver sin IA

El usuario reporta: al preguntarle a MIA algo como "¿cuántos viajes hice hoy?" (con datos reales ya cargados — ejemplo del propio usuario: "si yo tengo cinco viajes en cinco localidades"), la respuesta es que la IA todavía no está configurada (el error 503 de `proveedorSinImplementar`, ver Fase 9), **en vez de responder con el dato real**, que el Intent Router de Fase 8 (regla `viajes_hoy`, ya existente en `reglas.ts`) debería resolver sin tocar ningún proveedor de IA.

**Esto es un bug o una desconexión, no una limitación esperada** — el diseño documentado en "Estado real de Fase 10" dice explícitamente que `procesarTurnoConversacion` prueba el Intent Router PRIMERO y solo cae al proxy de IA si el router no reconoce la intención. Si el usuario ve el error de IA para una pregunta que sí matchea una regla conocida, hay algo fallando en el camino entre `ConversacionScreen.tsx` (arma el `contexto` con los datos de viajes/mantenimiento) y `conversacion.ts` (debería devolver la respuesta armada sin más). No se investigó todavía en qué punto se rompe — candidatos, sin confirmar: el `contexto` no se está armando o mandando bien desde el cliente, la normalización del texto hablado no matchea el patrón esperado por la regla (ej. transcripción de voz con variaciones que `reglas.ts` no contempla), o el router sí devuelve la intención pero sin la `respuesta` armada (¿falta algún campo del `contexto` que `armarRespuesta` necesita?).

**Pendiente para la próxima sesión, en orden:**
1. Revisar `ConversacionScreen.tsx` — confirmar que arma y manda `contexto.hoy` de verdad antes de llamar a `/ai/conversacion`.
2. Revisar `reglas.ts` — confirmar que la transcripción real de voz para una pregunta como "cuántos viajes hice hoy" efectivamente matchea el patrón de la regla `viajes_hoy` (la normalización de texto se probó en Fase 8 con texto escrito a mano, no con transcripciones reales de voz, que pueden variar más).
3. Si ambos están bien, revisar `conversacion.ts`/`router.ts` — confirmar que cuando el router SÍ reconoce la intención y arma la `respuesta`, `procesarTurnoConversacion` la devuelve directo sin intentar `generarAnalisis` (proxy de IA).

## 🆕 Pendiente nuevo — Diseño visual + expansión funcional (PDF del usuario, esta sesión)

El usuario mandó un PDF con lo que quiere para la pantalla de trabajo (tarjeta de pulso con neto/km/jornada, tiempo real vs. tiempo muerto, $/hora, gastos de jornada con costo por km, "Agregar viaje manual") y dos paneles nuevos enteros: **Deudas y Hogar**, y **Balance general**. Junto con eso mandó 20 capturas reales de su app anterior **NOAH** (no mockups — la UI real de esa app funcionando), que sirven como referencia visual de layout/tarjetas/animación de pulso — **el código de NOAH no se toca ni se reutiliza, solo se mira para entender la distribución que el usuario quiere** (mismo criterio que D-1: solo se reutiliza código cuando hay una razón técnica real, nunca "porque ya existe en algún lado").

**Regla explícita del usuario para todo este trabajo, por encima de cualquier otra consideración de estilo:** no repetir lo que hizo la IA anterior — nunca montar un archivo nuevo encima de uno que ya tiene el problema para "solucionarlo por fuera". Si algo hay que corregir, se corrige el archivo que ya existe. Si algo hay que agregar, se extiende el módulo que ya existe (mismo patrón D-8) — nunca un archivo paralelo, nunca una función duplicada con otro nombre. Ver D-18.

**Diagnóstico (hecho esta sesión, revisando el código real del zip):**

| | Existe hoy | Reutilizable tal cual | Falta construir |
|---|---|---|---|
| Tiempo real de cada viaje | ✅ `Viaje.inicioISO`/`finISO` | Sí, cálculo directo | Nada — solo falta la función que reste las fechas |
| Tiempo total/muerto de jornada | ✅ `Jornada.inicioISO`/`finISO`/`viajesIds` | Sí | Función pura que sume los tiempos de los viajes de la jornada y reste contra el total |
| Resúmenes Hoy/Semana/Mes | ✅ `domain/estadisticas/calculos.ts` (`agruparPorPeriodo`) | Sí | Nada, ya sirve para "Resumen del turno/día" (punto 3 del PDF) |
| Mantenimiento (recordatorio) | ✅ `domain/mantenimiento` | Es OTRA cosa — hoy es "cuándo toca", no "cuánto costó" | Nada se reutiliza para gastos, son conceptos distintos |
| Gastos de jornada (gasolina/aceite/etc. con valor en pesos) | ❌ No existe | — | `domain/gastos` nuevo, completo (cliente + backend) |
| Costo por km (gasolina/mantenimiento/operación) | ❌ No existe | Depende de `domain/gastos` | Cálculo derivado, una vez exista `domain/gastos` |
| "Agregar viaje manual" | ❌ No existe (solo flujo GPS automático) | El `Viaje` y `finalizarViaje` de `domain/viajes` sí se reutilizan tal cual | Solo el formulario/pantalla, ningún tipo nuevo |
| Deudas | ❌ No existe | — | `domain/deudas` nuevo, completo |
| Hogar (gastos fijos + gastos únicos) | ❌ No existe | — | `domain/hogar` nuevo, completo, con lógica de "gasto fijo se autogenera cada mes" |
| Balance general | ❌ No existe | Se arma agregando los 4 dominios de arriba | No es un dominio con datos propios — es una vista que cruza `viajes`+`gastos`+`deudas`+`hogar` |
| Rediseño visual (tema NOAH/otro) | `design/tokens.css` existe pero es plano/genérico | El archivo en sí (nunca se crea uno nuevo) | Las variables/clases del tema elegido, componente de tarjeta de pulso animada |
| Fusionar Viajes+Mantenimiento+Estadísticas en "Resumen" | Ya acordado con el usuario (ver abajo) | Los 3 stores se reutilizan tal cual (D-3: un store por dominio, no hace falta fusionarlos) | Reestructurar `App.tsx` + `features/` |
| MIA como burbuja flotante | Ya acordado con el usuario (ver abajo) | `domain/conversacion` se reutiliza tal cual | Solo capa visual/navegación en `App.tsx` |

**Aclaración del usuario sobre la estructura visual (importante, cambia el alcance del Bloque 4):** el panel de Mantenimiento (recordatorio de servicio) **tiene que quedar integrado dentro del mismo panel de trabajo** junto con Viajes, Jornada, Gastos de jornada y Estadísticas — no como pestaña/ruta aparte. La idea explícita del usuario: "toda la zona de trabajo de Uber como tal, de las aplicaciones, tiene que ir en un solo panel y no en seis o siete paneles diferentes". Esto amplía lo que ya se había acordado (fusionar Viajes+Mantenimiento+Estadísticas) para que **Gastos de jornada también entre ahí**, no como pantalla separada. Dentro de esa única pantalla, cada cosa vive en su propia sección/tarjeta interna (scroll, no pestañas de navegación) — el usuario dejó explícito que confía en que se estructure bien internamente ("si tú dices que toca crear paneles independientes dentro de ese panel general, hazlo bien, sin dañar nada"), lo importante para él es que de la barra de navegación de abajo no cuelguen 6-7 rutas para lo que es una sola zona de trabajo.

**Por qué Mantenimiento y Gastos siguen siendo DOS cosas distintas aunque compartan pantalla (aclarado por el usuario con su propio ejemplo):** Mantenimiento (`domain/mantenimiento`, ya existe) es un **recordatorio determinístico** — "cada 6.000 km toca cambiar llantas", se dispara solo comparando contra el km acumulado, sin importar cuánto costó ni cuándo. Gastos con costo por km (`domain/gastos`, Bloque 3) es una **cifra que cambia cada período** — si en un mes se hacen 100 km y se gastan $100.000 en llantas, el km sale a $1.000; si al mes siguiente se hacen 200 km con el mismo gasto, sale a $500. Son datos independientes que conviene mostrar juntos en pantalla (por eso van en el mismo panel), pero nunca se mezclan en el mismo cálculo ni el mismo dominio — mantenimiento nunca necesita saber cuánto costó algo, gastos nunca decide cuándo toca un servicio.

**Estructura de paneles resultante (alineada con la que el usuario ya conoce de NOAH — ver capturas):**
1. **Panel "Trabajo"** (el panel único de la zona operativa) — secciones internas: tarjeta de pulso (neto/km/jornada), iniciar/terminar jornada, iniciar/finalizar viaje + agregar viaje manual, tarjetas de métricas (tiempo real/muerto, $/hora, km, costo/km), Mantenimiento (recordatorios, tal cual existe hoy), Gastos de jornada (registro + historial), resumen Hoy/Semana/Mes (`domain/estadisticas`).
2. **Panel "Casa y Deudas"** — Hogar / Deudas / Ahorro como sub-secciones (mismo patrón de sub-tabs que ya tenía NOAH), alimentado por los dominios nuevos del Bloque 3.
3. **Panel "Balance"** — vista agregada que cruza los dos paneles anteriores.
4. **MIA** — burbuja flotante, visible desde cualquiera de los 3 paneles, nunca un panel propio.
5. **Cuenta / Planes** — quedan como utilidades aparte (no son "zona de trabajo de Uber"), se revisa su ubicación exacta en el Bloque 4 sin que sea parte del pedido central.



### Bloque 1 — Corregir bugs existentes (código), antes de agregar nada nuevo
No tiene sentido construir funciones nuevas encima de una base con bugs conocidos sin corregir. En orden:
1. **GPS en segundo plano** (pendiente crítico arrastrado de Fase 5, ver esa sección abajo): agregar try/catch visible alrededor de `iniciarSeguimientoGPS` en `domain/viajes/store.ts` — corregir ESE archivo, no crear un wrapper nuevo. Sin esto, cualquier prueba de la app en el dispositivo real sigue siendo a ciegas si algo del GPS falla.
2. **Bug de MIA** (ver sección "🆕 Pendiente nuevo — MIA no responde..." arriba): seguir los 3 pasos ya documentados ahí (revisar `ConversacionScreen.tsx` → `reglas.ts` → `conversacion.ts`/`router.ts`) y corregir el archivo donde esté el problema real — no agregar una capa nueva "por si acaso" antes de confirmar dónde se rompe.

### Bloque 2 — Funciones nuevas que reutilizan datos ya existentes (bajo riesgo, sin dominio nuevo) — ✅ COMPLETO
3. ~~Tiempo real de jornada / tiempo muerto / $-por-hora-real / $-por-hora-con-espera~~ — **HECHO**: `calcularTiempoJornada`/`calcularRentabilidadPorHora` en `domain/estadisticas/calculos.ts`. Sin UI todavía, a propósito (ver Bloque 4).
4. ~~"Agregar viaje manual"~~ — **HECHO**: `AgregarViajeManualScreen.tsx` (ruta `/viajes/manual`), `domain/viajes/types.ts` (`ViajeManualInput`) y `repository.ts` (`crearViajeManual`) extendidos, store con `agregarViajeManual` nuevo.

### Bloque 3 — Dominios nuevos (funcionalidad real, cliente + backend)
5. ~~`domain/gastos`~~ — **HECHO (sección 1/4).**
6. ~~`domain/deudas`~~ — **HECHO (esta sesión, sección 2/4).** Ver "Estado real de Bloque 3 — sección 2: domain/deudas" más abajo.
7. ~~`domain/hogar`~~ — **HECHO (esta sesión, sección 3/4).** Ver "Estado real de Bloque 3 — sección 3: domain/hogar" más abajo.
8. ~~Balance general~~ — **HECHO (esta sesión, sección 4/4 — última del Bloque 3).** Ver "Estado real de Bloque 3 — sección 4: Balance general" más abajo.

**✅ Bloque 3 completo — las 4 secciones. Antes de seguir con el Bloque 4 (rediseño visual), se le preguntó al usuario si continúa (mismo protocolo que al cerrar el Bloque 2).**

### Bloque 4 — Rediseño visual (al final, sobre una base funcional ya sólida)
9. El usuario eligió el tema aportando su propia guía visual (`visual.zip`, 20 capturas — reemplaza a los 3 mockups genéricos anteriores) en vez de elegir entre los 3 mockups ya generados. **HECHO, pero SOLO para el Panel "Trabajo"** — el usuario pidió explícitamente no tocar el resto todavía (ver "Estado real de Bloque 4 — parte visual (solo Panel Trabajo)"). Balance/Casa y Deudas/Cuenta/Planes siguen sin tema — decisión pendiente si se les aplica el mismo o distinto.
10. Aplicar el tema elegido a `design/tokens.css` — se EXTIENDE ese único archivo (D-8/Fase 6: nunca un `-extra.css`). **HECHO para el Panel "Trabajo"** (selector `.tema-trabajo`, scoped a propósito). **PENDIENTE para el resto de paneles.**
11. ~~Fusionar `ViajesScreen`+`MantenimientoScreen`+`EstadisticasScreen`+la pantalla de Gastos (Bloque 3) en un solo Panel "Trabajo"~~ — **HECHO (parte no visual, sección 1/2 de esta sesión).** `domain/deudas`/`domain/hogar` (Bloque 3) arman su propio **Panel "Casa y Deudas"** — **HECHO (sección 2/2)**. Ver "Estado real de Bloque 4 — parte no visual" más abajo. Falta solo vestirlo con el tema (eso es el ítem 10 aplicado a estas pantallas).
12. ~~Sacar a MIA de ruta aparte y convertirla en burbuja de micrófono flotante (overlay)~~ — **HECHO (parte no visual, sección 2/2)**: `MiaBurbuja.tsx`, sin animación/ícono todavía.
13. Construir la tarjeta de pulso animada (neto del día, km, estado de jornada) alimentada con datos reales de los stores ya existentes — **HECHO, datos + visual** (`SeccionPulso.tsx` reescrita esta sesión: estado del sistema, CTA degradado, grilla de 8 métricas Redondas/Recortadas/Resumen, todo con datos reales). **Sin animación de entrada/transición todavía** (motion propiamente dicho, no solo estilo estático) — pendiente si el usuario la pide.
14. Vestir con el tema elegido los formularios nuevos de los bloques 2 y 3 (gastos, deudas, hogar, viaje manual) — se hace al final para no vestir dos veces lo mismo si el layout cambia mientras se construye. **Gastos y viaje manual: HECHO (heredan `.tema-trabajo` por vivir dentro del Panel Trabajo). Deudas y Hogar: PENDIENTE** (viven en Panel "Casa y Deudas", fuera del alcance pedido esta sesión).

**Por qué este orden y no otro:** los bugs del Bloque 1 pueden estar afectando datos que los bloques siguientes van a mostrar (ej. si el GPS falla en silencio, el tiempo real de viaje del Bloque 2 estaría mal). Los dominios nuevos del Bloque 3 son la parte más grande y arriesgada — conviene tenerlos funcionando en su forma más simple (sin vestir) antes de invertir tiempo en el rediseño visual completo del Bloque 4, para no tener que rehacer estilos si algo del diseño de datos cambia sobre la marcha.

**Mockups de referencia visual (para el Bloque 4, imágenes del usuario, no incluidas en este zip):**
- Tema 1 — estilo propio, paleta neutra clara.
- Tema 2 — oscuro, tipo apps de chofer (Uber Driver / InDriver).
- Tema 3 — inspirado en las 20 capturas reales de NOAH que mandó el usuario: fondo negro-verdoso, tipografía editorial grande (serif) para títulos, tarjetas redondeadas translúcidas, acento verde-menta, píldoras de filtro (Hoy/Semana/Mes/Todo), botón de acción con degradado naranja→verde, tarjetas circulares/octogonales para métricas ("Lectura del día"), gráficas tipo "órbita" para distribución de ingresos en el panel de Balance. **El usuario aclaró explícitamente que el código de NOAH "quedó totalmente roto"** — se toma solo el lenguaje visual, nunca se reutiliza código de ahí (D-1 sigue aplicando: la única excepción real a "todo desde cero" son los plugins nativos de burbuja/alarma).

**Pendiente antes de escribir código real de cualquier bloque:** el usuario tiene que confirmar que este orden (Bloque 1 → 2 → 3 → 4) es el que quiere, y en algún punto antes del Bloque 4, elegir el tema visual.

## Estado real de Bloque 3 — sección 1 de 4: `domain/gastos` (hecho esta sesión)

**Contexto para quien retome esto (otra sesión/otra IA, si se corta acá):** el usuario pidió avanzar el Bloque 3 completo (dominios nuevos: gastos, deudas, hogar, balance) dividido en 4 secciones, actualizando este plan después de cada una. Esta es la sección 1/4. **Faltan las secciones 2 (`domain/deudas`), 3 (`domain/hogar`) y 4 (Balance general)** — seguir ese orden, es el mismo de la lista de arriba (ítems 6, 7, 8).

**Hecho:**

Cliente (`app/src/domain/gastos/`, patrón D-8 idéntico a mantenimiento):
- `types.ts` — `Gasto` (categoría `gasolina|aceite|llantas|mantenimiento|otro`, monto, fecha, litros opcional solo con sentido en 'gasolina', notas). **Append-only a propósito** (sin editar/eliminar) — mismo criterio que `RegistroMantenimiento`, documentado en el propio archivo para que no se agregue edición/borrado sin resolver antes cómo se propagaría al backend (el diseño de sync de D-16 no soporta borrados).
- `repository.ts`, `store.ts` (`useGastos`, con `agregarGasto` y `totalEnRango` ya pensado para lo que va a necesitar el Balance general en la sección 4), `api.ts`, `sync.ts` — todos calcados del patrón de mantenimiento.
- `features/gastos/GastosScreen.tsx` — pantalla mínima SIN vestir (Bloque 4 la funde en el panel único "Trabajo" y le aplica el tema elegido), formulario + historial. Reutiliza las clases CSS genéricas ya existentes (`pantalla`, `titulo-pantalla`, `texto-mute`, `tarjeta-viaje`), no crea CSS nuevo.
- `App.tsx` — ruta `/gastos`, ítem de navegación nuevo, y `registrarSincronizacionAutomatica('gastos', sincronizarGastosPendientes)` (reutiliza `lib/autoSync.ts` tal cual, con backoff y reintento al recuperar internet). **Nota a propósito, no es un descuido:** esto deja la barra de navegación en 7 rutas, lo cual contradice el pedido explícito del usuario de "no 6-7 paneles" — es intencional y temporal: ese pedido es del Bloque 4 (fusionar todo en el panel "Trabajo"), que todavía no llegó. No fusionar antes de tiempo porque el layout puede cambiar con el tema elegido (razón ya documentada en "Por qué este orden y no otro").

Backend (`server/`):
- `prisma/schema.prisma` — modelo `Gasto` nuevo (mismo criterio que `RegistroMantenimiento`: `id` es el UUID del cliente, sin FK a ningún ítem). `Usuario.gastos` agregado.
- `modules/sync/` — `types.ts` (`GastoSyncEntrada`), `schemas.ts` (`esquemaGastoSync`, valida la categoría con `z.enum`), `repository.ts` (`buscarGastoPorId`/`guardarGasto`), `service.ts` (`sincronizarGasto`, reutiliza `verificarPertenencia`), `routes.ts` (`POST /sync/gastos`, comparte el mismo `limitadorSync` que los demás — a propósito, ver comentario ya existente en ese archivo).
- **Se verificó a mano, con `grep`, que ningún import relativo nuevo quedó sin `.js`** (el bug real `TS2835` del primer build de Render) y que el handler de la ruta nueva tiene `(req: Request, res: Response)` explícito (el otro bug real, `TS7006`) — mismos dos errores que ya rompieron el build una vez, no debería repetirse por estos archivos nuevos.

**No verificado (mismo límite de siempre — sin red/Postgres/`tsc` real en este entorno):** falta correr `npx prisma migrate dev` con el modelo `Gasto` nuevo, y probar `POST /sync/gastos` contra el backend real desplegado.

**Siguiente paso:** sección 2/4 — `domain/deudas` (ítem 6 de la lista de Bloque 3).

## Estado real de Bloque 3 — sección 2 de 4: `domain/deudas` (hecho esta sesión)

**Contexto para quien retome esto (otra sesión/otra IA, si se corta acá):** siguiendo el mismo pedido del usuario (Bloque 3 en 4 secciones). **Faltan las secciones 3 (`domain/hogar`) y 4 (Balance general)** — seguir con la 3 (ítem 7 de la lista de Bloque 3).

**Decisión de diseño nueva en esta sección (no estaba en el plan original, hubo que resolverla acá):** a diferencia de Gasto/RegistroMantenimiento (append-only), una `Deuda` tiene un saldo que BAJA con cada abono — es decir, es **mutable**, como `Jornada`. Se sincroniza igual que Jornada: reenviándose completa vía upsert en cada abono, deliberadamente **sin soporte de borrado** (mismo problema sin resolver que `ItemMantenimiento` — no se agregó `eliminarDeuda`, documentado en `types.ts` para que nadie lo agregue sin resolver antes cómo se propagaría al backend). El historial de abonos (`AbonoDeuda`) sí es append-only, mismo patrón de siempre, pero con una diferencia real respecto a `RegistroMantenimiento`: `deudaId` es un **FK real** hacia `Deuda` en el backend (`itemId` en cambio es una referencia suelta, sin FK, porque `ItemMantenimiento` no se sincroniza). Eso significa que si un abono se sube antes que su deuda, el FK lo rechaza — se resolvió en dos capas: (1) `domain/deudas/sync.ts` no intenta subir un abono cuya deuda siga marcada `pendienteDeSync` (evita gastar el request en vano); (2) `service.ts`/`routes.ts` en el backend igual capturan el P2003 (violación de FK) y devuelven un 409 claro por si el abono llega antes de todos modos — la garantía real es esta segunda capa, la primera es solo una optimización.

**Hecho:**

Cliente (`app/src/domain/deudas/`, patrón D-8):
- `types.ts` — `Deuda` (nombre, saldoInicial, saldoActual, cuotaProgramada opcional con monto+frecuencia) y `AbonoDeuda` (historial). Ambos con el razonamiento de mutabilidad/FK de arriba documentado in situ.
- `repository.ts` — dos colas de sync independientes (`deudasPendientesDeSync`/`abonosPendientesDeSync`), mismo patrón que `RepositorioMantenimiento` (items+registros).
- `store.ts` (`useDeudas`) — `agregarDeuda`, `abonar` (crea el `AbonoDeuda` Y actualiza `saldoActual` de la deuda en la misma operación — el saldo nunca baja de 0 aunque se abone de más, pero el abono en sí se guarda completo, nunca se recorta), `deudasActivas`.
- `api.ts`/`sync.ts` — `sync.ts` combina las dos colas en un solo `ResultadoSincronizacion` (para poder registrarlo con `registrarSincronizacionAutomatica` igual que los demás dominios) y aplica el orden deuda-antes-que-abono explicado arriba.
- `features/deudas/DeudasScreen.tsx` — pantalla mínima sin vestir (Bloque 4 la funde en el panel "Casa y Deudas" junto con Hogar): alta de deuda con cuota opcional, lista de activas con campo de abono inline, lista de pagadas. Reutiliza clases CSS genéricas existentes, no crea CSS nuevo.
- `App.tsx` — ruta `/deudas`, ítem de navegación (mismo caveat temporal que Gastos: la barra ya tiene 8 rutas, se funde en Bloque 4, ver sección 1) y `registrarSincronizacionAutomatica('deudas', sincronizarDeudasPendientes)`.

Backend (`server/`):
- `prisma/schema.prisma` — modelos `Deuda` (mutable, `cuotaProgramada` como `Json?` — es opcional como bloque completo, no campo por campo) y `AbonoDeuda` (con FK real `deudaId → Deuda.id`, `onDelete: Cascade`). `Usuario.deudas`/`Usuario.abonosDeuda` agregados.
- `modules/sync/` — `types.ts` (`DeudaSyncEntrada`, `AbonoDeudaSyncEntrada`), `schemas.ts` (`esquemaDeudaSync`, `esquemaAbonoDeudaSync` — valida `cuotaProgramada` con un sub-schema y que `deudaId` sea un UUID), `repository.ts` (`buscarDeudaPorId`/`guardarDeuda`, `buscarAbonoDeudaPorId`/`guardarAbonoDeuda` — esta última deja propagar el error de Prisma tal cual, sin traducirlo: esa traducción vive en `service.ts`, no en el repositorio, mismo criterio de capas que ya usa `verificarPertenencia`), `service.ts` (`sincronizarDeuda`, `sincronizarAbonoDeuda` — esta última atrapa el código `P2003` de Prisma y lo convierte en `ErrorSync` 409), `routes.ts` (`POST /sync/deudas`, `POST /sync/deudas/abonos` — **se cuidó de no loguear el 409 de "deuda todavía no sincronizada" como evento de seguridad**: solo el 403 real de pertenencia dispara `logEventoSeguridad`, para no saturar ese log con reintentos normales de un flujo offline-first).
- **Se verificó a mano, con `grep`, que ningún import relativo nuevo quedó sin `.js`** y que los 2 handlers nuevos tienen `(req: Request, res: Response)` explícito — mismos dos bugs reales del primer build de Render, no deberían repetirse.

**No verificado (mismo límite de siempre):** falta correr `npx prisma migrate dev` con los modelos `Deuda`/`AbonoDeuda`, y probar en vivo el caso de carrera real (abono llegando antes que su deuda) contra el backend desplegado — se razonó a mano que el 409 se dispara, pero no se ejecutó contra una base real.

**Siguiente paso:** sección 4/4 — Balance general (ítem 8 de la lista de Bloque 3). Última sección del Bloque 3.

## Estado real de Bloque 3 — sección 3 de 4: `domain/hogar` (hecho esta sesión)

**Contexto para quien retome esto (otra sesión/otra IA, si se corta acá):** siguiendo el mismo pedido del usuario (Bloque 3 en 4 secciones). **Falta la sección 4 (Balance general)** — es la última del Bloque 3 (ítem 8 de la lista).

Dos entidades, mismo motivo y mismo patrón que Deuda/AbonoDeuda (sección 2):

- `ConceptoFijo` — la plantilla recurrente ("Arriendo, $500.000, día 5 de cada mes"). MUTABLE (el monto esperado cambia con el tiempo, ej. sube el arriendo) y sincroniza por upsert. Sin soporte de borrado a propósito (D-16, mismo motivo que Deuda): en vez de borrar, se desactiva (`activo=false`) — deja de autogenerar gastos nuevos, conserva el historial ya generado.
- `GastoHogar` — historial real, append-only (igual que Gasto). Cubre tanto los gastos "únicos" que el usuario carga a mano (`conceptoFijoId: null`) como los autogenerados cada mes a partir de un `ConceptoFijo` activo (`tipo: 'fijo'`).

**La pieza central — autogeneración de gastos fijos (lo que pedía el ítem 7 explícitamente):**

- `domain/hogar/calculos.ts` — `calcularGastosFijosPendientes(conceptos, gastosExistentes, ahora)`, función PURA (D-10, no toca el repositorio ni genera ids): por cada `ConceptoFijo` activo, si no existe ya un `GastoHogar` de ese concepto fechado en el mismo año-mes que `ahora`, lo marca para generar — con fecha en el `diaDelMes` de ESE mes (recortado al último día real si el mes es más corto, ej. día 31 en septiembre → día 30), no la fecha de hoy. `store.ts` (`cargar()`) llama a esta función cada vez que se abre la pantalla y persiste + agrega al estado cualquier gasto que falte generar — el usuario nunca tiene que darle a un botón para que aparezcan.
- **Verificado con `node`** (reimplementación en JS plano, mismo criterio de siempre): 6 casos, todos correctos — (1) concepto sin historial este mes genera uno, con la fecha del `diaDelMes` y no la de hoy; (2) un gasto ya generado este mes no se duplica; (3) un concepto desactivado nunca genera, aunque no tenga historial; (4) un mes nuevo sí genera de nuevo aunque haya historial de meses anteriores; (5) `diaDelMes=31` en un mes de 30 días se recorta a 30; (6) con dos conceptos, solo genera el que todavía no tiene gasto este mes.

**Resto del cliente (mismo patrón D-8 de siempre):**

- `domain/hogar/repository.ts` — dos colas en `localStorage` (`mia:hogar:conceptos`, `mia:hogar:gastos`), mismo shape que `RepositorioDeudas`.
- `domain/hogar/store.ts` — `agregarGastoUnico`, `agregarConceptoFijo`, `actualizarMontoConceptoFijo` (D-18: el monto que cambia se actualiza en el concepto existente, nunca se crea uno nuevo "por las dudas"), `desactivarConceptoFijo`, `conceptosActivos()`.
- `domain/hogar/api.ts`/`sync.ts` — `sincronizarHogarPendiente()`, mismo diseño de dos colas con dependencia de orden que `domain/deudas/sync.ts`: `GastoHogar.conceptoFijoId` es FK real hacia `ConceptoFijo` en el backend, así que un concepto todavía pendiente bloquea (en esa pasada) la subida de los gastos que generó — se reintentan solos en la próxima pasada del backoff (`lib/autoSync.ts`), sin necesidad de manejo especial.
- `features/hogar/HogarScreen.tsx` — pantalla mínima SIN vestir (Bloque 4 la funde en el panel "Casa y Deudas" junto con Deudas): formulario de gasto único, formulario de gasto fijo (con día del mes), lista de fijos activos con edición de monto inline + botón desactivar, historial ordenado por fecha. Reutiliza clases CSS genéricas existentes, no crea CSS nuevo.
- `App.tsx` — ruta `/hogar`, ítem de navegación (mismo caveat temporal que Gastos/Deudas: la barra ya tiene 9 rutas, se funde en Bloque 4) y `registrarSincronizacionAutomatica('hogar', sincronizarHogarPendiente)`.

**Backend:**

- `prisma/schema.prisma` — modelos `ConceptoFijo` (mutable, sin borrado) y `GastoHogar` (append-only, con FK real `conceptoFijoId → ConceptoFijo.id`, `onDelete: Cascade`, nullable para los gastos únicos). `Usuario.conceptosFijos`/`Usuario.gastosHogar` agregados.
- `server/src/modules/sync/` — extendido con `ConceptoFijoSyncEntrada`/`GastoHogarSyncEntrada` (types.ts), `esquemaConceptoFijoSync`/`esquemaGastoHogarSync` (schemas.ts, con Zod), `buscarConceptoFijoPorId`/`guardarConceptoFijo`/`buscarGastoHogarPorId`/`guardarGastoHogar` (repository.ts, upsert por id), `sincronizarConceptoFijo`/`sincronizarGastoHogar` (service.ts — mismo `verificarPertenencia` compartido, y la misma traducción de violación de FK (P2003 → 409) que ya usa `sincronizarAbonoDeuda`), y las rutas `POST /sync/hogar/conceptos-fijos` / `POST /sync/hogar/gastos` (routes.ts, mismo `limitadorSync` compartido y mismo logging de `sync_conflicto_pertenencia` en el 403).

**Verificación hecha esta sesión:** además de los 6 casos de `node` sobre `calcularGastosFijosPendientes`, se revisó a mano — con los dos chequeos de siempre en todo `server/src` — que no quedara ningún import relativo sin extensión `.js` ni ningún handler `req`/`res` sin anotar (los dos bugs reales que aparecieron la sesión pasada al compilar en Render/GitHub Actions). Ambos chequeos salieron limpios. También se verificó a mano el balance de llaves `{}` de los 5 archivos del módulo `sync` tras editarlos.

**No verificado (mismo límite de siempre — sin red/Postgres/`npm install` real en este entorno):** no se pudo compilar TypeScript real ni correr esto contra un backend real. El riesgo de que el *diseño* esté mal es bajo (es exactamente el mismo patrón que `Deuda`/`AbonoDeuda`, ya usado y ya revisado), el riesgo real está en typos o detalles de Prisma que solo aparecen al migrar de verdad — mismo aviso que las secciones anteriores del Bloque 3.

**Siguiente paso:** sección 4/4 — Balance general (ítem 8 de la lista de Bloque 3, última del Bloque 3). No es un dominio nuevo con su propio store — es una pantalla/cálculo que agrega `viajes`+`gastos`+`deudas`+`hogar` ya cargados (D-10: la coordinación entre dominios va en la capa de orquestación, nunca dentro de un store).

## Estado real de Bloque 3 — sección 4 de 4: Balance general (hecho esta sesión — Bloque 3 COMPLETO)

**Contexto para quien retome esto:** esta es la última sección del Bloque 3. Con esto, **el Bloque 3 completo queda hecho** (gastos, deudas, hogar, balance) — lo que sigue, si el usuario da luz verde, es el Bloque 4 (rediseño visual).

A diferencia de las 3 secciones anteriores, esto NO es un dominio nuevo — no hay `repository.ts` ni `store.ts` ni `sync.ts` nuevos, ni modelo Prisma nuevo, ni endpoint nuevo. Es exactamente lo que decía el ítem 8: una función pura que cruza los 4 dominios que ya existen.

- `domain/balance/calculos.ts` — `calcularBalanceGeneral(viajes, gastos, deudas, gastosDeHogar)`, función PURA (D-10): recibe los 4 arrays ya cargados por sus propios stores, no le pertenece ningún dato. Reutiliza `calcularResumen` de `domain/estadisticas/calculos.ts` para el total de ingresos (D-18: ese cálculo ya existía, no se volvió a escribir). Devuelve `ingresosTotales`, `gastosOperativos` (suma de `domain/gastos`), `gastosDeHogar` (suma de `domain/hogar`), `deudaPendienteTotal` (suma de `saldoActual` de todas las deudas, nunca negativo por deuda individual) y `balanceNeto` (ingresos - gastos operativos - gastos de hogar — **a propósito no resta la deuda pendiente**: el balance neto es sobre el flujo de plata ya movido, la deuda es una obligación futura, se muestran por separado para no mezclar los dos conceptos).
- **Verificado con `node`** (mismo criterio de siempre): 4 casos, todos correctos — (1) caso normal con los 4 dominios con datos, incluyendo un viaje "en_curso" que correctamente NO cuenta en los ingresos; (2) una deuda con `saldoActual` negativo (pagada de más) no resta del total pendiente, queda en 0; (3) los 4 arrays vacíos dan todo en 0 sin `NaN`; (4) el balance neto puede dar negativo (se gastó más de lo que entró) sin romperse.
- `features/balance/BalanceScreen.tsx` — pantalla sin vestir (Bloque 4 la funde en el panel "Balance", ver la sección de estructura de paneles más arriba). Es la única pantalla del proyecto que le pide datos a 4 stores a la vez (`useViajes`, `useGastos`, `useDeudas`, `useHogar`) — exactamente el tipo de coordinación que D-10 reserva para la capa de orquestación. Se confirmaron a mano los nombres exactos de cada store (`viajes`/`gastos`/`deudas`/`gastos` de `useHogar`, todos con `cargar()`) antes de conectarla, para no romper nada.
- `App.tsx` — ruta `/balance` + ítem de navegación. **No** se registró sincronización automática para este módulo — no tiene datos propios, solo lee lo que los otros 4 dominios ya sincronizan por su cuenta.

**No verificado (mismo límite de siempre):** no se pudo compilar TypeScript real ni ver esto renderizado. El riesgo es bajo — es la pieza más simple de las 4 secciones del bloque (una función pura + una pantalla de solo lectura, sin backend nuevo, sin sync nuevo).

**✅ Bloque 3 completo.** Antes de seguir con el Bloque 4 (rediseño visual — la parte más grande y menos definida de todo el proyecto, con 20 capturas de referencia de NOAH de por medio), preguntarle al usuario si continúa, igual que se hizo al cerrar el Bloque 2.



Decisión tomada con el usuario al iniciar la fase: Mantenimiento cubre **ítems predefinidos + personalizados** (ambos); Estadísticas muestra lo básico **+ desglose por plataforma y por zona/localidad de Bogotá**.

Hecho:

1. **`domain/mantenimiento/`** (patrón D-8: types/repository/store, más `reglas.ts` con el catálogo):
   - `types.ts` — `ItemMantenimiento`, `RegistroMantenimiento`, `EstadoAlerta`, con criterio `'km' | 'dias' | 'km_o_dias'` (lo que pase primero, ver arquitectura Fase 2 sección 3).
   - `reglas.ts` — `CATALOGO_MANTENIMIENTO` con 8 ítems típicos de carro de uso intensivo (aceite, llantas, frenos, filtro de aire, alineación, batería, SOAT, técnico-mecánica) con intervalos de referencia editables; `calcularEstadoAlerta()` calcula km/días faltantes y marca vencido o "próximo a vencer" (margen de 500 km / 15 días).
   - `repository.ts` — localStorage, mismo patrón que `RepositorioViajesLocal`.
   - `store.ts` — `useMantenimiento`: cargar, agregar desde catálogo, agregar personalizado, eliminar (solo personalizados), marcar realizado (crea registro histórico + actualiza `ultimoKm`/`ultimaFechaISO` del ítem).
   - **Importante:** este dominio NUNCA calcula el km del vehículo por su cuenta — lo recibe como parámetro (`kmActual`), que la pantalla obtiene de `domain/estadisticas/calculos.ts` (`calcularResumen(viajes).kmTotales`), que a su vez lo deriva de `domain/viajes` (única fuente de verdad real).

2. **`domain/estadisticas/`** — a propósito **sin repository ni store propios**: es solo un módulo de funciones puras (`calculos.ts`) que deriva de `Viaje[]` (de `domain/viajes`, vía `useViajes`). No duplica el dato de km/ingreso/plataforma/zona, solo lo agrega.
   - `calcularResumen()`, `agruparPorPeriodo()` (día/semana ISO/mes), `desglosePorPlataforma()`, `desglosePorZona()` (usa el campo `zona` que ya resuelve `domain/viajes` contra `zonasBogota.ts`, agrupando lo no detectado en "Sin zona detectada").
   - **Decisión D-11 — Gastos y ganancia neta NO se calculan todavía:** `domain/gastos` no existe como módulo (solo estaba nombrado como ejemplo futuro en D-3/D-8). Estadísticas muestra ingresos, km y cantidad de viajes, y dice explícitamente en la UI que gastos/ganancia neta se agregan cuando ese dominio exista. No se inventó un número de "gastos" en cero disfrazado de dato real — se prefirió ser explícito con el hueco.

3. **`features/mantenimiento/MantenimientoScreen.tsx`** y **`features/estadisticas/EstadisticasScreen.tsx`** — nuevas pantallas, mismo estilo que `ViajesScreen.tsx`.

4. **Navegación real agregada** — `App.tsx` ahora usa `react-router-dom` (`HashRouter`, porque la app corre empaquetada en Capacitor, no como sitio con rutas de servidor) con una barra de navegación fija abajo (Viajes / Mantenimiento / Estadísticas). Antes `App.tsx` solo montaba `ViajesScreen` a secas.

5. `design/tokens.css` — se agregaron `.insignia` (ok/próximo/vencido) y `.barra-navegacion`, siguiendo la regla de "un solo archivo de tokens, nunca `-extra.css`".

**No se pudo verificar que compile ni corre** — mismo límite que en Fase 5: este entorno no tiene red para `npm install` ni forma de correr Vite/TypeScript de punta a punta. La próxima corrida del workflow de GitHub Actions (o `npm run build` local si el usuario consigue un PC) es la primera vez que se prueba esta cadena.

Pendiente para cerrar Fase 6:

1. Verificar que el build compile (subir a GitHub y correr el workflow, o `npm install && npm run build` si hay PC disponible).
2. Probar en el APK: agregar un ítem del catálogo, marcar uno como realizado, agregar uno personalizado, ver que las 3 pantallas naveguen bien con la barra de abajo.
3. Decidir si se quiere notificación/alerta proactiva (push o local notification) cuando un ítem se vence, o si por ahora basta con verlo al entrar a la pantalla (no se construyó nada de notificaciones en esta fase, `@capacitor/local-notifications` ya está en `package.json` sin usar).
4. `domain/gastos` sigue sin existir — cuando se construya (no está en las 14 fases originales como una fase propia, quedó implícito en D-3), Estadísticas se actualiza para calcular ganancia neta real.

## Estado real de Fase 7 (para la próxima sesión)

Hecho:

1. **`server/prisma/schema.prisma`** — modelos `Usuario`, `TokenRefresco`, `Plan`, `PlanDeUsuario`. Postgres (D-4). El refresh token se guarda **hasheado** (SHA-256), nunca en texto plano — mismo criterio que una contraseña.
2. **`modules/auth/`** completo:
   - `password.ts` (bcryptjs, 12 rondas), `jwt.ts` (access token JWT corto, 15 min por defecto), `refreshTokens.ts` (refresh token **opaco**, no JWT — así se puede revocar por fila en la base de datos sin depender de que expire un JWT firmado).
   - `service.ts` — `registrar` (crea usuario + le asigna el plan gratis automáticamente, ver punto 3), `iniciarSesion` (mismo mensaje de error si el email no existe o la contraseña es incorrecta, a propósito, para no filtrar qué emails están registrados), `refrescarSesion` (con **rotación**: el refresh token usado se revoca y se emite uno nuevo).
   - `middleware.ts` — `requiereAutenticacion`, único lugar que lee el header `Authorization`.
   - `routes.ts` — `POST /auth/registro`, `POST /auth/login`, `POST /auth/refrescar`, `GET /auth/yo` (ruta protegida de referencia).
3. **`modules/plans/`** — solo lo que pide D-6 para *ahora*: el plan `gratis` se crea solo al arrancar el server (`asegurarPlanGratisExiste`, idempotente) y se asigna automáticamente a cada usuario nuevo. **Google Play Billing y validación de recibo NO están aquí** — eso es Fase 11 a propósito, no se adelantó ni se simuló.
4. **`http/asyncHandler.ts` + `http/errorHandler.ts`** — manejo de errores centralizado (Zod → 400, `ErrorAuth` → su código HTTP, cualquier otra cosa → 500 sin filtrar detalles internos al cliente).
5. `server/tsconfig.json` — no existía (mismo hueco que tuvo el cliente antes de Fase 5), se creó ahora.
6. `server/.env.example` — variables necesarias (`DATABASE_URL`, dos secretos JWT distintos para poder revocar acceso sin invalidar refresco, tiempos de expiración).
7. `package.json` del backend actualizado con `bcryptjs`, `jsonwebtoken`, `zod` y sus tipos, más scripts `prisma:generate` / `prisma:migrate` / `prisma:deploy`.

**No se pudo verificar que esto corra ni una vez** — sin red no se pudo `npm install`, y tampoco hay una instancia de Postgres disponible en este entorno para correr `prisma migrate dev` contra una base real. Es la misma limitación de siempre, ver sección de Fase 5.

Pendiente para cerrar Fase 7 (en orden):

1. Conseguir una base Postgres (local con Docker, o algo como Neon/Supabase gratis) y correr `npx prisma migrate dev --name init` para generar la primera migración real — hoy solo existe el `schema.prisma`, nunca se corrió contra una base de datos de verdad.
2. Llenar `server/.env` con secretos JWT generados de verdad (el comando para generarlos está en `.env.example`).
3. Probar el flujo completo a mano (con curl, Postman o Thunder Client): `POST /auth/registro` → `GET /auth/yo` con el token → `POST /auth/refrescar` → confirmar que el token viejo ya no sirve (rotación).
4. Conectar el cliente (`app/`) a estos endpoints — **hecho parcialmente en la continuación de Fase 10**: ya existe `app/src/lib/api.ts` (POST autenticado y sin autenticar) y `app/src/features/auth/CuentaScreen.tsx` (login/registro). Sigue sin probarse de punta a punta porque no hay Postgres real en este entorno para levantar el backend. El resto de dominios (`viajes`, `mantenimiento`, `estadisticas`) sigue siendo 100% local (localStorage) — la sincronización real de esos datos con el backend sigue siendo Fase 13, esto solo resolvió la autenticación que Fase 10 (voz) necesitaba.
5. Decidir dónde se despliega esto (sigue en "Qué falta decidir", no es nuevo de esta fase).

## Estado real de Fase 8 (léelo antes de seguir — HECHA con salvedades, no "perfecta")

División de la fase en 4 partes (la misma de la sesión anterior), y qué pasó con cada una en esta sesión:

1. **[HECHO]** Capa de reglas determinísticas — ya existía, se amplió.
2. **[HECHO, como stub]** Clasificador con IA de respaldo — existe el código y el punto de enganche, pero NO llama a ningún modelo real todavía (ver detalle abajo, esto es intencional).
3. **[HECHO, con una decisión de diseño nueva]** Conectar cada intención con datos reales — resuelto sin esperar a Fase 13 (ver detalle abajo).
4. **[PENDIENTE — sigue siendo Fase 9, no se tocó]** Contexto compacto + proxy de IA completo.

### Punto 1 — Reglas (ampliado esta sesión)

- `modules/ai/reglas.ts` — `REGLAS_INTENT` pasó de 3 a **5 intenciones**: se agregaron `viajes_hoy` y `resumen_semana`. Se agregaron porque ya hay datos reales para responderlas (`calcularResumen`, `agruparPorPeriodo` con unidad `'semana'` en `app/src/domain/estadisticas/calculos.ts`), **no porque se confirmara contra el documento de requisitos original** — esta sesión tenía instrucción explícita de leer solo este archivo, no ese documento. Sigue pendiente confirmar contra ese documento qué otras intenciones faltan.

### Punto 2 — Clasificador IA de respaldo (nuevo esta sesión, como stub deliberado)

- `modules/ai/clasificadorIA.ts` — tipo `ClasificadorIntentIA` (interfaz inyectable) + `clasificadorSinImplementar`, la implementación por defecto: **no llama a ningún modelo**, siempre devuelve `'no_reconocida'`. Es un stub a propósito, no un olvido: qué proveedor de IA usar sigue sin decidirse (ver "Qué falta decidir" — es la misma pregunta pendiente para el proxy de Fase 9). No correspondía elegir un proveedor por mi cuenta en este corte.
- `modules/ai/router.ts` — `resolverIntencion(texto, contexto?, clasificadorIA?)` ahora es **async** y recibe el clasificador como parámetro con ese stub de default. Cuando se decida el proveedor, se escribe una función con la misma forma (`(texto) => Promise<ResultadoIntent>`) y se pasa como tercer argumento — no hace falta tocar el resto del router.

### Punto 3 — Conectar con datos reales (nuevo esta sesión — decisión de diseño, revisar)

En vez de que el backend consulte km/ingresos/mantenimiento (lo que exigiría sync real, Fase 13), se optó por la opción que la sesión anterior ya había dejado anotada como alternativa: **el cliente manda el dato ya calculado junto con la pregunta**, porque `domain/estadisticas` y `domain/mantenimiento` ya lo calculan localmente hoy.

- `modules/ai/types.ts` — nuevo `ContextoIntent` (`hoy`, `semana`, `mantenimiento`), todo opcional. Los shapes `ContextoResumen` y `ContextoMantenimientoItem` están duplicados a mano (no importados) desde `ResumenViajes` y `EstadoAlerta` del cliente — a propósito, porque `server/` no depende de `app/` (D-8). **Si esos tipos cambian del lado del cliente, esto no se entera solo.**
- `modules/ai/respuestas.ts` (nuevo) — `armarRespuesta(intencion, contexto)`: función pura que arma el texto final ("Hoy llevas 123,4 km en 7 viajes.", etc.) cuando el dato que esa intención necesita vino en `contexto`; si no vino, devuelve `null` y la ruta responde igual que antes (solo la intención, sin texto).
- `modules/ai/routes.ts` — `POST /ai/intent` ahora acepta `{ texto, contexto? }`, valida `contexto` con Zod, y devuelve `respuesta` en el JSON.
- `modules/ai/router.ts` — arma `respuesta` cuando una regla matchea.

**Esto NO conecta la UI real todavía** — ninguna pantalla de `app/src/features/` llama a este endpoint ni arma `contexto` desde los stores. Eso sigue pendiente y es trabajo de cliente, no de este módulo.

**Esta es una decisión de arquitectura que no estaba en las "Decisiones tomadas" (D-1 a D-10) — revisarla con el usuario antes de darla por definitiva.** Alternativa: si más adelante se prefiere que el backend sea dueño de los datos (vía sync, Fase 13) en vez de recibirlos por request, este endpoint se puede migrar sin romper el contrato público (`texto` seguiría funcionando igual; `contexto` se volvería innecesario).

### Punto 4 — Sigue sin tocar, es Fase 9.

**Actualización: Fase 9 ya se hizo (ver "Estado real de Fase 9" más abajo) — este punto 4 quedó resuelto ahí, no aquí.**

### Verificación hecha esta sesión

**No se corrió el código TypeScript real ni una vez** — mismo límite que el resto del proyecto en este entorno (`npm install` da 403, sin red). Sí se verificó la lógica (normalización de texto, matching de reglas, armado de respuestas con distintos `contexto`, incluyendo casos sin contexto y con listas vacías de mantenimiento) reimplementándola en JavaScript plano fuera del proyecto y corriéndola con `node` — el comportamiento fue el esperado en todos los casos probados, pero **esto no reemplaza compilar y correr el TypeScript real** (tipos de Zod, de Express, etc. sin verificar). Antes de dar Fase 8 por cerrada de verdad: correr `npm install` (con red) y al menos un `curl` a `POST /ai/intent` con y sin `contexto`.

### Pendiente real para cerrar Fase 8 del todo

1. Confirmar contra el documento de requisitos original qué intenciones faltan (punto 1 — no se releyó ese documento en este corte, ver nota arriba).
2. Decidir el proveedor de IA para el clasificador de respaldo (sigue en "Qué falta decidir") y escribir la implementación real de `ClasificadorIntentIA`.
3. Confirmar con el usuario la decisión de diseño del punto 3 (contexto por request vs. esperar a Fase 13/sync) — no es un asunto cerrado, es la opción que pareció más razonable sin poder preguntar en el momento.
4. Compilar y probar el código de verdad en cuanto haya `npm install` con red.

## Estado real de Fase 9 (léelo antes de seguir — HECHA con salvedades, mismo patrón que Fase 8)

Fase 9 es "IA analista (proxy + contexto compacto)" (docs/FASE2-ARQUITECTURA.md, sección 6, punto 5): para preguntas que necesitan que un modelo *razone* sobre los datos del conductor (ej. "¿cómo puedo mejorar mis ingresos este mes?"), no solo mapear a una respuesta fija como hace el Intent Router de Fase 8.

Hecho:

1. **`modules/ai/types.ts`** — se agregaron `ProfundidadAnalisis` (`'normal' | 'profundo'`), `ContextoPuntoPeriodo`, `ContextoAnalisis` (extiende `ContextoIntent` de Fase 8 con `historial` opcional) y `ResultadoAnalisis`.
2. **`modules/ai/contextoCompacto.ts`** (nuevo) — `armarContextoCompacto(contexto, profundidad)`, función pura. Convierte el `contexto` crudo (números que el cliente ya calculó) en líneas de texto cortas, no JSON crudo. En profundidad `'normal'` recorta el historial a los últimos 8 períodos; en `'profundo'` lo manda completo. Esto es lo que la arquitectura (Fase 2, sección 3, fila "Historial de IA / contexto") llama "el backend arma el contexto compacto, el cliente nunca decide qué mandarle al modelo" — el cliente aporta los números, este archivo decide qué entra en el prompt y cómo.
3. **`modules/ai/proveedorIA.ts`** (nuevo) — mismo patrón que `clasificadorIA.ts` de Fase 8: tipo `ProveedorIA` (`(prompt) => Promise<string>`) inyectable, con `proveedorSinImplementar` como default. A diferencia del clasificador de Fase 8 (que se degrada en silencio a `'no_reconocida'`), acá el stub **lanza** `ErrorProveedorIANoConfigurado` (503) en vez de inventar una respuesta — no tiene sentido fingir un análisis con IA cuando el usuario pidió explícitamente eso. `http/errorHandler.ts` ya sabe traducir ese error.
4. **`modules/ai/analisis.ts`** (nuevo) — `generarAnalisis(pregunta, contexto, profundidad, proveedorIA?)`: arma el contexto compacto + una instrucción de sistema fija ("responde en español, corto, solo con los datos del contexto, no inventes cifras") + la pregunta, y se lo pasa al proveedor inyectado.
5. **`modules/ai/routes.ts`** — nueva ruta `POST /ai/analisis` (protegida), separada de `POST /ai/intent`. Acepta `{ pregunta, contexto?, profundidad? }` (contexto reutiliza los mismos campos de Fase 8 más `historial` opcional; `profundidad` por defecto `'normal'`).
6. `http/errorHandler.ts` e `index.ts` actualizados para reconocer el nuevo error y reflejar que `modules/ai` ya no está vacío ni a medias.

**Por qué el proveedor real sigue sin implementarse:** "Proveedor de IA definitivo para el proxy del backend (Fase 9)" sigue en "Qué falta decidir" — no era una decisión que correspondiera tomar sola. El proxy quedó armado para que conectar el proveedor real sea escribir una sola función nueva con la forma `(prompt) => Promise<string>` y pasarla como argumento a `generarAnalisis` — ningún otro archivo debería necesitar cambios.

**Verificación hecha esta sesión:** igual que Fase 8, no se pudo compilar ni correr el TypeScript real (sin red para `npm install` en este entorno). Sí se probó la lógica equivalente en JavaScript plano fuera del proyecto: recorte de historial a 8 períodos en profundidad `'normal'` vs. historial completo en `'profundo'`, contexto vacío/ausente, y que el stub del proveedor efectivamente rechaza con el error 503 en vez de responder algo — todos los casos se comportaron como se esperaba, pero esto no reemplaza correr el TypeScript real (tipos de Zod/Express sin verificar).

**Lo que NO se hizo (fuera de alcance real, no un olvido):**
- Conectar la UI (`app/src/features/`) a este endpoint — ninguna pantalla llama a `/ai/analisis` todavía, igual que con `/ai/intent` de Fase 8.
- Persistencia de historial de conversación — cada llamada a `/ai/analisis` es sin estado (no guarda nada en base de datos); conversación continua multi-turno es explícitamente Fase 10 ("depende de que el Intent Router y el proxy de IA ya funcionen bien por texto", docs/FASE2-ARQUITECTURA.md sección 6). No se adelantó nada de eso.
- Política de retención/borrado del historial de IA para el formulario de Data Safety de Google Play (docs/FASE2-ARQUITECTURA.md sección 5) — sigue siendo tema de Fase 14, no bloqueaba escribir el código de Fase 9, pero hay que resolverlo antes de publicar.

## Estado real de Fase 10 (léelo antes de seguir — EN CURSO, código escrito, sin probar)

Fase 10 es "Voz + conversación continua" (docs/FASE2-ARQUITECTURA.md sección 6, punto 6: "al final, porque depende de que el Intent Router y el proxy de IA ya funcionen bien por texto" — Fase 8 y 9 ya estaban hechas con salvedades, así que correspondía seguir con esta).

Hecho esta sesión:

1. **Backend — `server/src/modules/ai/conversacion.ts`** (nuevo) — `procesarTurnoConversacion(texto, contexto?, profundidad?, clasificadorIA?, proveedorIA?)`: prueba el Intent Router (Fase 8) primero; si resolvió una intención reconocida CON respuesta armada, la devuelve directo (rápido, gratis, sin IA). Si no, arma un bloque de texto con los últimos 6 turnos previos de la conversación y lo antepone a la pregunta antes de pasarla al proxy de IA (Fase 9, `generarAnalisis`).
2. **`server/src/modules/ai/types.ts`** — se agregaron `TurnoConversacion`, `ContextoConversacion` (extiende `ContextoAnalisis` con `turnosPrevios` opcional) y `ResultadoConversacion`.
3. **`server/src/modules/ai/routes.ts`** — nueva ruta `POST /ai/conversacion` (protegida), acepta `{ texto, contexto?, profundidad? }` donde `contexto` reutiliza el shape de `/ai/analisis` más `turnosPrevios` (array de `{pregunta, respuesta}`, máximo 20 — es la conversación de una sesión, no un historial permanente, ver D-11).
4. **Cliente — `app/src/lib/api.ts`** (nuevo) — primera conexión real de `app/` hacia `server/` (ver D-11). `postAutenticado()` (rutas protegidas) y `post()` (sin autenticar, para `/auth/*`), más `obtenerTokenAcceso`/`obtenerTokenRefresco`/`guardarTokens`/`borrarTokens`/`haySesion` (JWT en `localStorage`, claves `mia:tokenAcceso`/`mia:tokenRefresco`) y `ErrorSinSesion` para cuando todavía no hay token. *(El login/registro que consume esto se construyó en la continuación de esta misma fase — ver más abajo, "Continuación: pantalla de login".)*
5. **`app/src/domain/conversacion/`** (nuevo dominio, sin `repository.ts` a propósito — ver types.ts):
   - `types.ts` — `TurnoConversacion`, `EstadoConversacion`, `ResultadoTurno`.
   - `voz.ts` — reconocimiento de voz (STT) y texto a voz (TTS), con el mismo patrón nativo/web que `domain/viajes/gps.ts`: en Android nativo usa `@capacitor-community/speech-recognition` + `@capacitor-community/text-to-speech` (D-12); en navegador cae a la Web Speech API (`SpeechRecognition`/`speechSynthesis`) para poder desarrollar la UI sin dispositivo.
   - `api.ts` — llama a `POST /ai/conversacion` usando `lib/api.ts`.
   - `store.ts` (zustand, sin persistencia) — `turnos` de la conversación actual, `estado` (`inactiva`/`escuchando`/`procesando`/`hablando`/`error`), y `escucharYResponder(contexto?)` que encadena escuchar → mandar al backend → leer la respuesta en voz alta.
6. **`app/src/features/conversacion/ConversacionScreen.tsx`** (nuevo) — capa de orquestación: cruza `domain/viajes` + `domain/mantenimiento` para armar `contexto` (mismo principio D-10 que `ViajesScreen.tsx` usa para jornada/viajes), botón de micrófono, checkbox de "conversación continua" (si está prendido, en cuanto el asistente termina de hablar se vuelve a escuchar sola), lista del historial de turnos, botón "Nueva conversación".
7. **`app/App.tsx`** — nueva ruta `/conversacion` + ítem "MIA" en la barra de navegación.
8. **`app/package.json`** — se agregaron `@capacitor-community/speech-recognition` y `@capacitor-community/text-to-speech`.
9. **`app/android/.../AndroidManifest.xml`** — se agregó `RECORD_AUDIO`.
10. **`app/.env.example`** (nuevo) — `VITE_API_URL`, con nota sobre `10.0.2.2` en emulador Android vs. `localhost`.
11. De paso, se encontró que **`app/` nunca tuvo `.gitignore`** (hueco real, no un pendiente escrito en este plan) — se agregó uno básico (`node_modules/`, `dist/`, `.env`) porque ahora sí existe un `.env` real (`VITE_API_URL`) que no debería subirse a GitHub.

**Por qué el proveedor de IA real sigue sin importar acá:** `/ai/conversacion` reutiliza `generarAnalisis` (Fase 9) tal cual, que sigue dependiendo del stub `proveedorSinImplementar` (503). Si una pregunta de voz no la resuelve ninguna regla del Intent Router, hoy la respuesta hablada sería un error, no una frase — aceptable mientras el proveedor de IA sigue en "Qué falta decidir", pero hay que tenerlo presente al probar en dispositivo real: hoy solo las 5 intenciones de `reglas.ts` (Fase 8) van a funcionar de punta a punta por voz.

**Decisión de diseño nueva, sin confirmar con el usuario — revisar:** en `ConversacionScreen.tsx`, "esta semana" se aproxima tomando el bucket de semana MÁS RECIENTE de `agruparPorPeriodo(viajes, 'semana')`, no necesariamente la semana calendario actual — si el conductor no ha viajado esta semana todavía, eso mostraría la última semana con viajes en vez de "cero esta semana". Documentado en el propio código; no se resolvió mejor porque `claveSemana()` (el cálculo real de semana ISO) no está exportado desde `domain/estadisticas/calculos.ts` — exportarlo y comparar contra la semana de hoy es la corrección correcta, queda pendiente.

**Verificación hecha esta sesión:** igual que las fases anteriores del módulo `ai`, no se pudo compilar ni correr TypeScript real (`npm install` sin red en este entorno) ni menos aún probar el reconocimiento de voz o el texto a voz (necesitan micrófono/parlante reales, imposible en este entorno). Sí se reimplementó en JavaScript plano y se corrió con `node` la lógica de `conversacion.ts` (decidir camino rápido vs. proxy de IA, recorte de `turnosPrevios` a los últimos 6) — se comportó como se esperaba, pero esto no reemplaza compilar el TypeScript real ni probar la voz en un Android físico.

**Lo que NO se hizo (pendiente real para cerrar Fase 10):**

1. ~~Bloqueante para probar de punta a punta: construir la pantalla de login/registro en `app/`~~ — **resuelto en la continuación de esta fase, ver subsección abajo.** Sigue habiendo un bloqueante distinto: no hay Postgres real en este entorno, así que ni con la pantalla de login se pudo probar de punta a punta.
2. Confirmar en un Android físico que `@capacitor-community/speech-recognition` y `@capacitor-community/text-to-speech` funcionan como se espera (nombres de métodos/eventos escritos de memoria, sin poder consultar la documentación exacta de la versión instalada porque no hay red en este entorno) — antes de eso, tratar `voz.ts` como "probablemente correcto, no confirmado", mismo espíritu que el resto de plugins nativos del proyecto.
3. Decidir si vale la pena exportar `claveSemana()` de `calculos.ts` para que "esta semana" en la conversación sea exacto y no una aproximación (ver arriba).
4. Conectar `turnosPrevios` directo en `contextoCompacto.ts` (Fase 9) en vez de antepuesto a la pregunta a mano en `conversacion.ts` — mejora de prompt, no bloqueante (ver comentario en el propio `conversacion.ts`).
5. Confirmar las versiones exactas de `@capacitor-community/speech-recognition` y `@capacitor-community/text-to-speech` en `package.json` contra npm real (se escribieron versiones razonables de memoria, sin poder correr `npm view` sin red) — ajustar en cuanto haya `npm install` con red.
6. Política de retención/borrado del audio de voz para el formulario de Data Safety de Google Play — sigue siendo Fase 14, no bloqueaba escribir el código de Fase 10, pero el audio de voz es justo el tipo de dato que ese formulario pide declarar (docs/FASE2-ARQUITECTURA.md sección 5).
7. Decidir si "conversación continua" necesita algún límite de turnos o de tiempo antes de apagarse sola (hoy sigue indefinidamente hasta que el usuario destilde el checkbox o cierre la pantalla) — no se decidió porque no había con quién confirmarlo, quedó con el comportamiento más simple.

### Continuación: pantalla de login/registro (cierra el pendiente #1 de arriba, y el pendiente #4 de Fase 7)

Hecho en esta segunda sesión sobre Fase 10:

1. **`app/src/lib/api.ts` (reescrito)** — antes solo tenía `postAutenticado()`. Se agregó `post()` sin autenticar (para `/auth/registro`, `/auth/login`, `/auth/refrescar`, que no llevan `Authorization`), manejo de **ambos** tokens (acceso + refresco, antes solo se contemplaba el de acceso), y `haySesion()`.
2. **`app/src/domain/auth/`** (nuevo dominio, sin `repository.ts` a propósito — la sesión es el token que ya guarda `lib/api.ts`):
   - `types.ts` — `Usuario`.
   - `api.ts` — `registrarse`, `iniciarSesion`, `refrescarSesion` (llaman a `POST /auth/registro|login|refrescar`).
   - `store.ts` (zustand) — `usuario`, `cargando`, `error`, `autenticado()` (delega en `haySesion()`), `registrarse`/`iniciarSesion`/`cerrarSesion`.
3. **`app/src/features/auth/CuentaScreen.tsx`** (nuevo) — una sola pantalla con toggle login/registro (ver D-13). Al loguearse con éxito, navega a `/conversacion`.
4. **`app/App.tsx`** — ruta `/cuenta` + ítem "Cuenta" en la barra de navegación.
5. **`app/src/features/conversacion/ConversacionScreen.tsx`** — ahora chequea `useAuth().autenticado()` antes de mostrar el micrófono; si no hay sesión, muestra un aviso con un botón que lleva a `/cuenta`, en vez de dejar que el usuario toque el micrófono y recién ahí se entere con un `ErrorSinSesion` después de haber hablado.

**Huecos conocidos de esta continuación (ver D-13 para el detalle):** no hay refresco automático de token todavía (un 401 a mitad de conversación no se reintenta solo); el objeto `usuario` no se restaura al recargar la app (solo el token persiste, así que `autenticado()` da `true` pero `usuario` puede ser `null` hasta el próximo login — la corrección sería llamar a `GET /auth/yo` al arrancar si hay token, no se hizo).

**Verificación:** mismo límite que el resto — no se pudo compilar TypeScript real ni correr esto contra un backend real (sin Postgres en este entorno). No hizo falta reimplementar lógica en JavaScript plano esta vez porque no hay lógica de cálculo nueva (es orquestación de llamadas HTTP + estado de formulario), pero eso significa que la revisión fue solo de lectura — no probada ni siquiera de forma indirecta.

## Estado real de Fase 11 (léelo antes de seguir — EN CURSO, código escrito, sin probar)

Fase 11 es "Google Play Billing (planes) + validación server-side" (D-6: "Google Play Billing Library en el cliente + endpoint en el backend que valida el recibo contra la API de Google. Ninguna pasarela de pago propia.").

Hecho esta sesión:

1. **`server/prisma/schema.prisma`** — `Plan` ganó `productIdGooglePlay` (SKU de Play Console, único, null para el plan gratis). `PlanDeUsuario` ganó `purchaseToken` (único — ver D-14, idempotencia).
2. **`server/src/modules/plans/types.ts`** — nuevo catálogo `PLANES_BASE` (antes solo existía la constante `CLAVE_PLAN_GRATIS`): `gratis` (como antes) + `pro_mensual` (`limiteConsultasIA: null` = ilimitado, `productIdGooglePlay: 'mia_pro_mensual'`). **Ese SKU es un valor elegido para que el código tenga algo concreto, no la confirmación de que ya existe en ninguna Play Console real** — no existe cuenta de desarrollador todavía (ver "Qué falta decidir").
3. **`server/src/modules/plans/repository.ts`** — `asegurarPlanGratisExiste()` (Fase 7) se **renombró y amplió** a `asegurarPlanesBaseExisten()`: ahora hace upsert de TODO `PLANES_BASE`, no solo gratis. Nuevas funciones: `buscarPlanPorProductoGoogle`, `desactivarPlanesActivosDeUsuario`, `buscarPlanDeUsuarioPorTokenDeCompra`; `asignarPlanAUsuario` ahora acepta `{ purchaseToken?, finISO? }` opcional.
4. **`server/src/modules/plans/service.ts`** — `asignarPlanGratisPorDefecto` ya no llama a "asegurar", solo busca el plan gratis (que el arranque del server ya garantiza que existe) — evita hacer upsert de todo el catálogo en cada registro de usuario.
5. **`server/src/modules/billing/`** (nuevo módulo):
   - `types.ts` — `ParametrosVerificacionCompra`, `EstadoCompraGoogle`, `VerificadorGooglePlay` (tipo inyectable, mismo patrón que `ClasificadorIntentIA`/`ProveedorIA`).
   - `googlePlay.ts` — **stub a propósito**: `verificadorSinConfigurar` lanza `ErrorBillingNoConfigurado` (503). El comentario del archivo detalla qué hace falta para la implementación real (cuenta de servicio de Google Cloud, paquete `googleapis`, llamada a `purchases.subscriptions.get` de la Android Publisher API v3, y opcionalmente Real-time Developer Notifications para renovaciones/cancelaciones) — no se escribió de memoria porque sin poder instalar `googleapis` ni probar contra el sandbox de Google, inventar la forma exacta de esa llamada sería peor que dejar el hueco explícito.
   - `service.ts` — `servicioBilling.validarCompra(usuarioId, packageName, productId, purchaseToken, verificador?)`: valida que `productId` mapee a un plan conocido (400 si no), revisa idempotencia por `purchaseToken` ANTES de llamar a Google (ver D-14), llama al verificador inyectado, y si la compra es válida desactiva los planes activos anteriores y crea el nuevo `PlanDeUsuario`.
   - `routes.ts` — `POST /billing/validar-compra` (protegida): `{ packageName, productId, purchaseToken }`.
6. **`http/errorHandler.ts`** — reconoce `ErrorBillingNoConfigurado` (503) y `ErrorBilling` (código según el caso: 400 producto desconocido, 402 compra inválida).
7. **`index.ts`** — monta `/billing`, y el arranque ahora llama a `asegurarPlanesBaseExisten()` en vez de la función vieja.
8. **`server/.env.example`** — nota sobre qué variables va a necesitar el verificador real cuando se escriba (`GOOGLE_SERVICE_ACCOUNT_JSON`, `GOOGLE_PLAY_PACKAGE_NAME`), sin agregarlas como obligatorias todavía (no tiene sentido romper el arranque del server por variables que ninguna implementación real usa aún).
9. **Cliente — `app/src/lib/api.ts`** — se agregaron `get()` (sin autenticar, catálogo público) y `getAutenticado()` (rutas protegidas tipo `GET /planes/actual`) — antes el archivo solo sabía hacer POST.
10. **`app/src/domain/planes/`** (nuevo, sin `repository.ts` — el plan lo decide el backend, no es un dato local): `types.ts`, `api.ts` (`listarPlanes`, `obtenerPlanActual`), `store.ts`.
11. **`app/src/features/planes/PlanesScreen.tsx`** (nuevo) — **de solo lectura a propósito** (ver D-14): muestra el plan actual del usuario (si hay sesión) y el catálogo completo, con una nota de que la compra dentro de la app no está disponible todavía para cualquier plan que no sea gratis. Deliberadamente NO se construyó un botón de "Comprar" que no complete una compra real.
12. **`app/App.tsx`** — ruta `/planes` + ítem "Planes" en la navegación.

**Verificación hecha esta sesión:** no se pudo compilar TypeScript real (sin red para `npm install`). Sí se reimplementó `servicioBilling.validarCompra` en JavaScript plano y se corrió con `node`: producto de Google desconocido se rechaza (400), una compra válida activa el plan correcto, el mismo `purchaseToken` mandado dos veces es idempotente (no se llama de nuevo al verificador, no se duplica ninguna fila), y una compra que Google marca como inválida se rechaza sin crear nada — los 5 casos se comportaron como se esperaba. Esto no reemplaza correr el TypeScript real ni, mucho menos, probar contra el sandbox de Google Play (imposible sin cuenta de desarrollador).

**Lo que NO se hizo (pendiente real para cerrar Fase 11, en orden):**

1. **Bloqueante real:** conseguir/confirmar una cuenta de desarrollador de Google Play — sin eso no hay Play Console, y sin Play Console no se puede crear el producto `mia_pro_mensual` de verdad, ni la cuenta de servicio que necesita el verificador, ni probar nada de esto de punta a punta.
2. Escribir el verificador real (`modules/billing/googlePlay.ts`) contra la Android Publisher API v3 en cuanto exista lo del punto 1 y haya red para instalar `googleapis`.
3. Integrar Google Play Billing Library del lado nativo Android (`app/android/`) — hoy `PlanesScreen.tsx` no dispara ninguna compra, solo muestra el plan actual. Sin esto, el usuario no tiene ninguna forma real de generar un `purchaseToken` para mandarle a `/billing/validar-compra`.
4. Real-time Developer Notifications (RTDN) — sin esto, una cancelación o falta de pago en una renovación NO revierte el plan solo; `validarCompra` solo se entera del estado en el momento en que el cliente la llama. Es una mejora de robustez, no bloqueante para un primer corte.
5. Decidir el precio real del plan pro (y si hace falta más de un plan pago) — decisión de negocio, no técnica, sigue en "Qué falta decidir".
6. Confirmar que `productIdGooglePlay: 'mia_pro_mensual'` es el nombre que efectivamente se va a usar en Play Console, o cambiarlo antes de que exista tráfico real (después de eso, cambiarlo rompe compras existentes).

## Estado real de Fase 12 (léelo antes de seguir — EN CURSO, código escrito, sin probar)

Fase 12 es "Seguridad (auth, rate limits, datos por usuario)". Auth ya estaba resuelta en Fase 7 (JWT propio, bcrypt, rotación de refresh tokens — D-5). Esta fase cerró lo que faltaba:

1. **`server/src/http/rateLimit.ts`** (nuevo) — `crearLimitadorDeTasa(ventanaMs, maximo, mensaje?)`, ventana fija en memoria, por IP (ver D-15). Cableado en:
   - `modules/auth/routes.ts` — `/registro`, `/login`, `/refrescar`: 10 intentos / 15 min por IP.
   - `modules/ai/routes.ts` — `/intent`, `/analisis`, `/conversacion`: 20 / minuto por IP.
   - `modules/billing/routes.ts` — `/validar-compra`: 5 / minuto por IP.
2. **`index.ts`** — `app.set('trust proxy', 1)`, `helmet()` (cabeceras de seguridad HTTP estándar), `cors({ origin: env.corsOrigenes })` (antes no había CORS configurado en absoluto).
3. **`config/env.ts`** — nueva `env.corsOrigenes` (lista separada por comas, `CORS_ORIGENES` en `.env`, con default razonable para desarrollo). `server/.env.example` y `server/package.json` (`cors`, `helmet`, `@types/cors`) actualizados.
4. **Auditoría de "datos por usuario"** (no generó cambios de código — se confirmó que ya estaba bien): se revisaron todas las rutas protegidas de `modules/*/routes.ts` y ninguna toma un `usuarioId` del body — todas usan `req.usuarioId` que sale exclusivamente del JWT verificado por `requiereAutenticacion` (`modules/auth/middleware.ts`). Es decir, no hay forma de que un usuario autenticado pida o modifique datos de otro usuario pasando un ID distinto en la request.

**Por qué CORS no es "la" protección acá:** una app Android nativa (Capacitor) no pasa por el chequeo de CORS de un navegador — eso solo protege llamadas hechas desde un navegador (Vite en desarrollo, o un futuro dashboard web). Lo que realmente protege los datos por usuario es el JWT + la auditoría del punto 4, no CORS.

**Verificación hecha esta sesión:** no se pudo compilar TypeScript real ni correr esto contra un backend real. Sí se verificó `crearLimitadorDeTasa` reimplementado en JavaScript plano con `node`: bloquea al superar el máximo dentro de la ventana, se resetea pasada la ventana, y dos IPs distintas no se pisan entre sí — los 3 casos se comportaron como se esperaba. `helmet`/`cors` no se pudieron probar en absoluto (paquetes nuevos, sin `npm install` en este entorno) — se usó su API pública documentada de memoria (`helmet()` y `cors({ origin })` son extremadamente estables y no han cambiado su forma básica en varias major versions), pero **tratar como "probablemente correcto, no confirmado"** hasta que corra un `npm install` real.

**Hecho en esta sesión (cierra los pendientes #4 y #5 de la lista anterior):**

4. **[HECHO]** `server/src/lib/logSeguridad.ts` (nuevo) — única puerta de salida para eventos de seguridad (`rate_limit_bloqueado`, `login_fallido`, `registro_rechazado`), imprime JSON de una línea a stdout con timestamp e IP. A propósito NO es una integración con un servicio de logging real (Datadog/Sentry/etc.) — eso depende de dónde se despliegue el backend, que sigue sin decidirse. Conectado en:
   - `http/rateLimit.ts` — loguea cada vez que una IP se bloquea por exceder el máximo (antes bloqueaba en silencio).
   - `modules/auth/routes.ts` — `/login` loguea `login_fallido` (sin el email, a propósito — no vale la pena que el log termine siendo una lista de emails válidos/inválidos); `/registro` loguea `registro_rechazado` con el motivo (acá sí, porque "ya existe una cuenta" no es información sensible de un tercero). Ambos casos: se loguea y se re-lanza el mismo error, `http/errorHandler.ts` sigue siendo el único que decide el status/forma de la respuesta HTTP — el logging no cambia ningún comportamiento visible para el cliente.
5. **[HECHO]** `index.ts` — `express.json()` pasó a `express.json({ limit: '256kb' })`, explícito en vez de heredar el default de Express sin que nadie lo hubiera revisado. Se eligió 256kb revisando las formas reales de los payloads (`modules/ai/types.ts`: `contexto`/`historial` son números y strings cortos, nada que se acerque a eso) — decisión razonada, no un número arbitrario.

**Verificación de esta sesión:** igual que el resto del proyecto, sin red no se pudo compilar ni correr el TypeScript real. Sí se verificó `crearLimitadorDeTasa` + `logEventoSeguridad` reimplementados en JavaScript plano con `node`: bloquea la 4ª request y la loguea en una línea JSON válida, otra IP no se pisa con la primera, y pasada la ventana se resetea — los 3 casos se comportaron como se esperaba.

**Lo que sigue sin hacerse (pendiente real para cerrar Fase 12 del todo):**

1. Confirmar `helmet`/`cors` contra el `npm install` real y un `curl` de verdad (headers de respuesta, preflight OPTIONS, etc.) — sigue bloqueado por falta de red en este entorno.
2. El rate limiter en memoria no sirve si el backend termina corriendo en más de una instancia — ver D-15. No es un problema hasta que se decida el despliegue (sigue en "Qué falta decidir").
3. `trust proxy` se dejó en `1` (un solo proxy delante) sin poder confirmarlo contra la plataforma de despliegue real, porque esa plataforma todavía no se eligió.
4. El logging de seguridad (punto 4 de arriba) hoy solo imprime a stdout — si el backend termina desplegado en algo que no persiste logs por su cuenta, esto se pierde. No se conecta a nada real todavía porque, otra vez, depende de dónde se despliegue (misma decisión pendiente que los puntos 2 y 3).

## Estado real de Fase 13 (para la próxima sesión)

Fase 13 es "offline + sincronización con dedupe". Alcance de este corte: **solo `domain/viajes`** — es el dominio que ya tenía la cola `pendienteDeSync` construida desde Fase 4/5 y el que más importa tener respaldado (es la fuente del ingreso real del conductor). Mantenimiento y jornada quedan para una continuación de esta misma fase, no es un olvido.

Hecho:

1. **`server/prisma/schema.prisma`** — modelo `Viaje` nuevo (`id` es el UUID que el cliente ya genera, NO `@default(uuid())` como los demás modelos — es a propósito, ese id es la clave de dedupe). `Usuario.viajes` agregado como relación inversa.
2. **`server/src/modules/sync/`** completo:
   - `types.ts` — `ViajeSyncEntrada`, declarado independiente del `Viaje` del cliente (D-8).
   - `schemas.ts` — validación con Zod, incluye que `id` sea un UUID de verdad.
   - `repository.ts` — `buscarViajePorId` (para la verificación de pertenencia) + `guardarViaje` (upsert real).
   - `service.ts` — `sincronizarViaje`: rechaza con 403 si el id ya pertenece a otro usuario, si no, upsert. Ver D-16 para el razonamiento completo del diseño (push-only, un viaje por request).
   - `routes.ts` — `POST /sync/viajes` (protegida, rate limit propio, loguea el caso de conflicto de pertenencia como evento de seguridad — reutiliza `lib/logSeguridad.ts` de Fase 12, se agregó el tipo `sync_conflicto_pertenencia`).
3. **`http/errorHandler.ts`** — reconoce `ErrorSync` (mismo patrón que `ErrorAuth`/`ErrorBilling`).
4. **`index.ts`** — monta `/sync`, y el límite de body de Fase 12 pasó de 256kb a 512kb con la razón documentada ahí mismo (un viaje largo con captura densa de GPS puede pesar más que un payload de texto).
5. **Cliente:**
   - `app/src/domain/viajes/api.ts` (nuevo) — `subirViaje`, arma el payload aplanando `distancia` a los 3 campos sueltos que espera el backend.
   - `app/src/domain/viajes/sync.ts` (nuevo) — `sincronizarViajesPendientes()`: recorre la cola local en secuencia, best-effort (un viaje que falla no frena los demás), no hace nada si no hay sesión (`haySesion()` de `lib/api.ts` — D-13).
   - `App.tsx` — la llama una vez al abrir la app (fire-and-forget, no bloquea el render).
   - `features/viajes/ViajesScreen.tsx` — también la llama justo después de `finalizarViaje`, para que la sincronización se sienta inmediata cuando hay internet.

**Verificación hecha esta sesión:** no se pudo compilar TypeScript real ni correr esto contra un backend/Postgres real — mismo límite de siempre (sin red en este entorno). Sí se reimplementó la lógica de `service.ts` y del orquestador en JavaScript plano y se corrió con `node`: un viaje nuevo se guarda, el mismo id reenviado por el mismo usuario actualiza en vez de duplicar, otro usuario mandando el mismo id se rechaza con 403, y el orquestador sigue con el resto de la cola aunque uno falle — los 4 casos se comportaron como se esperaba.

**Lo que NO se hizo (pendiente real, en orden):**

1. **Bloqueante para probar de punta a punta:** correr `npx prisma migrate dev` con los modelos `Viaje`, `Jornada` y `RegistroMantenimiento` contra una base Postgres real (sigue siendo la misma tarea pendiente de Fase 7, ahora con tres modelos más).
2. Probar `POST /sync/viajes`, `POST /sync/jornadas` y `POST /sync/mantenimiento/registros` con curl/Postman: un recurso nuevo, el mismo reenviado (confirmar que no duplica en la base de verdad, no solo en la simulación), y con el token de otro usuario contra un id ya existente (confirmar el 403 real) — para los tres, no solo viajes.
3. Nada de "bajar cambios" (pull) — si en algún momento se necesita multi-dispositivo, hay que diseñarlo aparte, no está resuelto ni a medias hoy.
4. Ninguno de los tres `sync.ts` (viajes, jornada, mantenimiento) reintenta con backoff ni se dispara solo al recuperar internet (ej. evento `online` del navegador/WebView) — hoy sincronizan en momentos puntuales (abrir la app, y justo después de la acción que generó el dato: cerrar un viaje, terminar/actualizar una jornada, marcar un mantenimiento realizado). Alcanza para el caso normal, pero algo cerrado sin internet y la app nunca más reabierta hasta el próximo turno queda esperando a ese próximo turno para subir — no es un bug, es una limitación conocida del alcance actual. **✅ RESUELTO esta sesión**, ver "Continuación de Fase 13 — retry con backoff" más abajo.

**Continuación de esta fase (hecho en esta sesión) — jornadas y registros de mantenimiento:**

Alcance de esta continuación: se sincronizan **jornadas completas** y **registros de mantenimiento** (el historial de "esto se hizo tal día"). Deliberadamente NO se sincronizan `ItemMantenimiento` (la configuración de qué mantenimientos existen) — un ítem se puede editar y **borrar** desde el cliente (`repositorioMantenimiento.eliminarItem`), y el diseño push-only con upsert por id (D-16) no tiene forma de propagar un borrado al backend: sincronizar ítems tal cual dejaría filas huérfanas cada vez que alguien borra uno localmente. Resolver eso bien necesita un diseño de borrado (tombstones o similar) que no se decidió — no es un olvido, está documentado en `schema.prisma` (modelo `RegistroMantenimiento`) y en `server/src/modules/sync/types.ts`.

Hecho:

1. **`schema.prisma`** — modelos `Jornada` y `RegistroMantenimiento` nuevos (mismo criterio que `Viaje`: `id` es el UUID del cliente, no `@default(uuid())`). `Usuario.jornadas` y `Usuario.registrosMantenimiento` agregados.
2. **`server/src/modules/sync/`** ampliado: `types.ts` (`JornadaSyncEntrada`, `RegistroMantenimientoSyncEntrada`), `schemas.ts` (validación Zod de los dos), `repository.ts` (buscar/guardar de los dos, mismo patrón upsert), `service.ts` (`sincronizarJornada`, `sincronizarRegistroMantenimiento`, con un helper `verificarPertenencia` compartido para no repetir la regla de los 403 tres veces), `routes.ts` (`POST /sync/jornadas`, `POST /sync/mantenimiento/registros`, **comparten el rate limiter de `/sync/viajes`** a propósito — es un cupo por usuario, no por endpoint, para que no se pueda esquivar repartiendo requests entre los tres).
3. **Cliente — jornada:** `domain/jornada/types.ts` con `pendienteDeSync`. Jornada era la única excepción al patrón de D-8 (persistencia suelta en `store.ts`, sin `repository.ts` propio) — se le creó `repository.ts` real y se reescribió `store.ts` para delegar en él, **sin cambiar la API pública** (`jornadaAbierta`, `iniciarJornada`, `terminarJornada`, `agregarViajeAJornadaAbierta`, `cargar`), así que `ViajesScreen.tsx` no se rompió. Nuevo `api.ts` (`subirJornada`) y `sync.ts` (`sincronizarJornadasPendientes`).
4. **Cliente — mantenimiento:** `pendienteDeSync` agregado SOLO a `RegistroMantenimiento`, nunca a `ItemMantenimiento` (ver el porqué arriba). Métodos `marcarRegistroSincronizado`/`registrosPendientesDeSync` agregados al repositorio existente. Nuevo `api.ts` (`subirRegistroMantenimiento`) y `sync.ts` (`sincronizarRegistrosMantenimientoPendientes`).
5. **Orquestación:** `App.tsx` dispara las tres sincronizaciones al abrir la app (viajes, jornadas, registros de mantenimiento). `ViajesScreen.tsx` sincroniza jornada justo después de cerrar un viaje (porque eso también actualiza la jornada abierta) y después de terminar una jornada. `MantenimientoScreen.tsx` sincroniza registros justo después de marcar un mantenimiento como realizado — mismo criterio de siempre: best-effort, no bloquea la UI.

**No verificado (mismo límite de siempre — sin red/Postgres en este entorno):** no se pudo correr la migración de Prisma ni probar ningún endpoint nuevo contra una base real. Sí se revisó a mano que el patrón de `service.ts`/`repository.ts` para jornada y registro sea estructuralmente idéntico al de viaje (que si se validó con `node` en la sesión anterior), así que el riesgo de que el diseño en sí esté mal es bajo — el riesgo real está en typos o detalles de Prisma que solo aparecen al migrar de verdad.

### Continuación de Fase 13 — retry con backoff (hecho en esta sesión)

Resuelve el pendiente #4 de arriba, para los tres dominios a la vez (viajes, jornada, mantenimiento):

- **`app/src/lib/autoSync.ts`** (nuevo) — `registrarSincronizacionAutomatica(nombre, sincronizar)`, genérico: cada dominio le pasa su propia función `sincronizarXPendientes` en vez de repetir la lógica tres veces (mismo criterio que D-8). Corre una vez al registrar; si algo queda sin sincronizar o hay `primerError`, programa un reintento con backoff exponencial (5s → 10s → 20s → 40s..., tope 5 minutos); si un intento sale limpio (todo sincronizado, o cola vacía), resetea el backoff a 5s. El evento `online` del navegador/WebView también dispara un intento inmediato y resetea el backoff — no hay que esperar el backoff largo si ya se recuperó internet.
- **`App.tsx`** — las tres llamadas sueltas (`void sincronizarXPendientes()`) se reemplazaron por `registrarSincronizacionAutomatica('x', sincronizarXPendientes)`. Las llamadas puntuales que ya existían en `ViajesScreen.tsx`/`MantenimientoScreen.tsx` justo después de cada acción (cerrar viaje, terminar jornada, marcar mantenimiento) **se dejaron tal cual** — siguen siendo un intento inmediato válido, independiente del ciclo de fondo con backoff que ahora vive en `App.tsx`.
- Se dejó deliberadamente sin exponer una forma de "desregistrar" — las tres sincronizaciones se registran una sola vez al abrir la app y viven mientras la app vive, nunca dentro de una pantalla que se monta/desmonta.

**Verificado con `node`** (reimplementación en JS plano de la lógica de backoff, mismo límite de siempre: sin poder compilar TS real) — 4 casos, todos correctos: (1) fallos consecutivos duplican la espera (5000→10000→20000→40000), (2) un éxito después de fallos resetea la espera a 5000, (3) cola vacía cuenta como éxito, no dispara reintento, (4) el backoff no supera el tope de 300000ms (5 min) aunque seguiría fallando indefinidamente.

**No verificado (no se puede en este entorno):** el evento `online` real del navegador/WebView, y que el listener sobreviva correctamente durante toda la vida de la app en un dispositivo real — solo se validó la lógica de backoff en sí, aislada del DOM.

## Despliegue — Render + Neon (decisión D-17, hecho esta sesión)

Con la decisión tomada, se dejó todo listo para que el usuario solo tenga que crear las dos cuentas y pegar una URL — nada de configurar campo por campo:

1. **`render.yaml`** (nuevo, en la raíz del repo) — Blueprint de Render: `rootDir: server`, build (`npm install && npx prisma generate && npm run build`) y start (`npx prisma migrate deploy && npm run start` — las migraciones corren solas en cada despliegue, porque el plan free de Render no trae terminal/Shell). `JWT_SECRETO_ACCESO`/`JWT_SECRETO_REFRESCO` con `generateValue: true` (Render los genera solo, seguros, nadie los escribe a mano). `DATABASE_URL` queda `sync: false` a propósito — ese sí lo pega el usuario a mano desde Neon, Render no puede adivinarlo.
2. **Fix real encontrado y corregido:** `server/src/config/env.ts` leía `process.env.PUERTO` (español) para el puerto del servidor. Render asigna el puerto real por la variable estándar `PORT` — sin este fix, el health check de Render habría fallado siempre. Ahora lee `PORT` primero, con `PUERTO` como fallback para desarrollo local (nadie más lo usaba).
3. **`.github/workflows/build-apk.yml` ampliado** — se le agregó un paso nuevo, "Publicar código fuente para Render", ANTES de instalar dependencias/compilar: hace `git add app server docs PLAN-MAESTRO.md` + commit + push de vuelta al repo. Es necesario porque Render construye desde archivos reales del repo, no sabe leer el `MIAPROYECTO.zip` — así el usuario sigue sin tener que subir carpeta por carpeta, el propio workflow "desempaqueta" el zip como archivos normales cada vez que lo actualiza. Requiere `permissions: contents: write` (agregado al workflow).
4. **`app/src/lib/api.ts`** (sin cambios de código, ya leía `VITE_API_URL` de antes) — el workflow ahora inyecta `VITE_API_URL=https://mia-backend.onrender.com` como variable de entorno justo al correr `npm run build`. Ese nombre de URL asume que "mia-backend" quede libre en Render (es el `name:` del servicio en `render.yaml`) — si Render le asigna otro nombre porque ya estaba tomado, hay que corregir esa línea en el workflow con la URL real.

**Pendiente — lo único que de verdad necesita al usuario, en orden:**

1. Crear cuenta en Neon (neon.tech, gratis, con GitHub o email) → crear un proyecto → copiar el `DATABASE_URL` que da (viene con `?sslmode=require`, dejarlo tal cual).
2. Crear cuenta en Render (render.com, gratis, conectar con GitHub) → "New" → "Blueprint" → elegir el repo → Render lee `render.yaml` solo y muestra qué va a crear → pegar el `DATABASE_URL` de Neon donde lo pida (es la única variable que pide a mano, las demás las genera o ya están en el archivo) → Apply.
3. Confirmar la URL real que Render le dio al servicio (dashboard → arriba del todo) — si no es exactamente `https://mia-backend.onrender.com`, avisar para corregir `VITE_API_URL` en el workflow.
4. Con eso desplegado, recién ahí tiene sentido el punto 1-2 pendiente de "Estado real de Fase 13" (correr la migración real y probar los tres endpoints con curl/Postman) — antes no había dónde probarlos.

**No verificado (no se puede sin las cuentas reales del usuario):** que el Blueprint de Render aplique sin errores, que `prisma migrate deploy` corra limpio contra Neon la primera vez, y que el health check de Render pase con el fix de `PORT`. Todo esto se revisó a mano contra la documentación de cada plataforma, no se probó en vivo.

### Primer intento real de build en Render — 2 clases de error encontradas y corregidas en TODO el backend

El Blueprint sí se aplicó (Neon conectado, `render.yaml` encontrado) y llegó a correr `npm run build` de verdad por primera vez en la historia de este proyecto — y falló, revelando dos bugs que existían desde que se escribió cada módulo, invisibles hasta ahora porque `npm run dev` (`tsx`) nunca los detecta, solo `tsc -b` (el build real) lo hace:

1. **`TS2835` — 85 imports relativos en 25 archivos sin extensión `.js`** (ej. `from './repository'` en vez de `from './repository.js'`). `tsconfig.json` usa `moduleResolution: "NodeNext"` (ESM real), que exige la extensión explícita del archivo compilado — no es opcional, es una regla del propio Node.js con ESM, no un capricho de configuración. Corregido con un script que revisó TODO `server/src`, no solo los archivos que aparecían en el log truncado.
2. **`TS7006` — parámetros `req`/`res` con tipo implícito `any`** en los 5 archivos de rutas (`ai`, `auth`, `billing`, `plans`, `sync`) que usan el wrapper `async(async (req, res) => {...})` de `http/asyncHandler.ts`, más el health-check `/salud` en `index.ts`. Se corrigió anotando explícitamente `(req: Request, res: Response)` en los 13 handlers que usan ese patrón, agregando `import type { Request, Response } from 'express'` donde faltaba. `middleware.ts`, `rateLimit.ts` y `errorHandler.ts` ya estaban bien tipados — se revisaron y no necesitaron cambios.

**No verificado todavía:** no hay forma de correr `tsc` real contra este proyecto en este entorno (no hay `express`, `@prisma/client` ni el resto de dependencias instaladas, y no hay red para instalarlas) — la corrección se hizo revisando el patrón a mano y confirmando con `grep` que no queda ningún caso de los dos patrones en todo `server/src`, pero la próxima corrida real en Render sigue siendo la primera prueba de verdad. Si vuelve a fallar el build, puede haber una tercera clase de error distinta que este repaso no cubrió — mandar el log completo, no solo las primeras líneas, para no repetir el mismo problema de "el error real estaba más abajo en el log".

### Segundo intento real (esta vez el APK, en GitHub Actions) — dependencias con nombre/versión inventados

El paso "Publicar código fuente para Render" sí funcionó (confirmado por el usuario: el diff en GitHub mostró los fixes de `.js` y `Request/Response` ya aplicados). Pero `npm install` del **cliente** (`app/`) falló: `@capacitor/text-to-speech@^7.0.0` no existe — 404 real del registry. Investigado: ese paquete nunca existió con ese scope. El real es de la comunidad, `@capacitor-community/text-to-speech` (mismo patrón que `@capacitor-community/speech-recognition`, que sí estaba bien). D-12 en este mismo documento tenía el nombre mal escrito desde que se tomó esa decisión — corregido ahí también.

Esto disparó una revisión más amplia: **ninguna versión de ninguna dependencia, en ningún `package.json` de este proyecto, se había podido confirmar contra el registry real** (mismo límite de siempre — sin red en este entorno, todo se escribió "a ojo" con el conocimiento de cada sesión). Se verificaron por búsqueda las más riesgosas (`vite`, `@vitejs/plugin-react`, `react-router-dom`, `@capacitor-community/text-to-speech`) y varias de las versiones exactas puestas (ej. `vite@^8.3.0`, cuando lo último real confirmado es `8.0.16`) no existen todavía. **Fix aplicado, en los dos `package.json` (`app/` y `server/`):** toda versión de la forma `^X.Y.Z`/`~X.Y.Z` con minor/patch específico se relajó a `^X.0.0` (mismo major, sin adivinar el patch exacto) — así `npm install` resuelve solo a lo que exista de verdad en esa rama mayor, en vez de fallar por un patch que no existe. Se dejaron intactas las 3 versiones ya confirmadas por búsqueda: `@capacitor-community/speech-recognition@^7.0.1`, `@capacitor-community/text-to-speech@^8.0.0`, `typescript@~6.0.2` (esta última además confirmada indirectamente: el entorno de esta sesión tiene instalado `typescript@6.0.3` globalmente, así que la serie 6.x existe de verdad).

**Lección para cualquier sesión futura de este proyecto:** un número de versión "razonable para la fecha actual" escrito sin poder consultar el registry real es una adivinanza, no un dato — cuando se agregue una dependencia nueva sin poder verificarla, hay que preferir `^X.0.0` (mayor confirmado, sin inventar el patch) en vez de una versión exacta con muchos decimales que "suena a que ya deberá existir para esta fecha".

**No verificado todavía:** sigue sin poder correrse `npm install` real en este entorno — la próxima corrida de GitHub Actions (cliente) y del build de Render (backend) son las primeras pruebas reales de que estas versiones relajadas efectivamente resuelven.

## Estado real de Bloque 4 — parte visual (solo Panel Trabajo)

**Referencia:** 20 capturas de pantalla del usuario (`visual.zip` — el `.rar` original no se pudo abrir, este entorno no tiene `unrar` ni acceso a internet para instalarlo; el usuario lo reenvió como `.zip`). Paleta oscura verde-azulada casi negra, acento degradado menta→dorado, tarjetas circulares/recortadas para métricas conmutables con píldoras (Redondas/Recortadas/Resumen), tipografía serif para titulares y monoespaciada para etiquetas tipo eyebrow. Se siguió la referencia tal cual la pidió el usuario ("quiero un tema así igual") — las capturas eran de NOAH (marca vieja); se adaptó el texto de marca a "MIA" donde correspondía, sin copiar branding ajeno.

**Alcance, respetado al pie de la letra:** SOLO el Panel "Trabajo". Decisión de arquitectura clave para lograrlo sin tocar nada más: el tema nuevo vive dentro de un único selector `.tema-trabajo` en `design/tokens.css` (extendido, no un archivo nuevo — D-18) aplicado una sola vez en el `<section>` raíz de `TrabajoScreen.tsx`. Nunca se tocó `:root` ni las clases genéricas a nivel global (`.pantalla`, `.tarjeta-viaje`, `.texto-mute`, etc.) — esas las siguen usando Balance/Casa y Deudas/Cuenta/Planes sin ningún cambio. Dentro de `.tema-trabajo` sí hay overrides de esas mismas clases (`.tema-trabajo .tarjeta-viaje {...}`), pero por estar anidados bajo el selector, no salen del panel.

**`SeccionPulso.tsx` — reescrita completa** (era la parte con más capturas de referencia):
- Encabezado tipo portada (eyebrow + título serif + subtítulo dinámico según haya o no jornada abierta).
- Tarjeta "Estado del sistema" (En curso / Pausa) + botón CTA con degradado (Iniciar/Terminar jornada).
- Selector Redondas/Recortadas/Resumen (estado local, sin tocar ningún store) con la grilla de 8 métricas reales: tiempo de jornada, tiempo real trabajado, tiempo muerto (`calcularTiempoJornada`, Bloque 2), dinero/hora real (`calcularRentabilidadPorHora`, Bloque 2), gasolina/km (`calcularCostoPorKm` filtrado a categoría 'gasolina' — antes ese filtro no existía, ahora la etiqueta sí corresponde al dato real), dinero que se va en espera (**`calcularDineroEnEspera` — función nueva en `domain/estadisticas/calculos.ts`**, hora muerta × tarifa real de la hora trabajada, verificada con `node`), kilómetros del día, mantenimiento del día (suma de gastos categoría 'mantenimiento' de hoy).
- Vista "Resumen": píldoras Hoy/Semana/Mes, neto grande, desglose por categoría (Gasolina/Mantenimiento/Aceite/Total), divisor "Operación y registros" con 2 botones que hacen scroll real a las secciones de abajo, e historial acordeón de los últimos 5 días (`agruparPorPeriodo`, ya existía).

**Dos decisiones para resolver ambigüedades de la guía que no se pueden despejar del todo con capturas recortadas — documentadas para no tener que redecidir:**
1. "Gasolina/km" usa específicamente gastos categoría `gasolina`, no el total de gastos (eso ya lo cubre el desglose de "Resumen").
2. La guía mostraba un botón "Agregar bono" — no se agregó: ese concepto no existe como dominio en MIA, y D-18 prohíbe crear botones que no lleven a nada real. Quedaron "Agregar viaje" y "Agregar gasto", los dos con acción real.

**Las otras 4 secciones (`SeccionViajesYJornada`, `SeccionMantenimiento`, `SeccionGastos`, `SeccionEstadisticas`):** NO se reescribieron a mano (ninguna de sus ~430 líneas de lógica se tocó, D-3) — heredan el tema nuevo automáticamente por los overrides de `.tema-trabajo` sobre las clases genéricas que ya usaban, más un `id` nuevo en cada una (para el scroll de los botones de arriba) y su encabezado cambiado a la clase serif `.tt-titulo-seccion`. No tienen la fidelidad visual completa de las capturas (esas mostraban formularios/listas más elaborados) — quedan con el look del tema pero la MISMA estructura de antes; si el usuario quiere que también se vistan a fondo (no solo hereden colores/fuentes), es la continuación natural de este mismo trabajo.

**No se pudo compilar ni ver esto renderizado ni una vez** — mismo límite de siempre (sin `npm install` en este entorno). Se verificaron con `node` las funciones puras nuevas (`calcularDineroEnEspera`, `formatoDuracion`, los rangos de semana/mes) y se confirmó a mano que las etiquetas JSX quedaron balanceadas en los 6 archivos tocados. La próxima sesión (o el usuario, si corre `npm run build`) debería revisar visualmente antes de seguir — es la primera vez que se escribe CSS de verdad en este proyecto.



**Alcance acordado con el usuario para este corte:** de los 6 ítems del Bloque 4 (9 a 14), se hizo TODO lo que no es diseño/tema — es decir, la reestructura real de pantallas, la fusión de paneles, MIA como burbuja, y la capa de datos de la tarjeta de pulso. **Los ítems 9, 10 y 14 (elegir tema, aplicar tema a `tokens.css`, vestir formularios) siguen 100% pendientes** — no se tocó ningún color, fuente, ni el archivo `tokens.css` en esta sesión. Todo lo nuevo reutiliza las mismas clases genéricas de siempre (`pantalla`, `titulo-pantalla`, `texto-mute`, `tarjeta-viaje`, `lista-viajes`, `insignia`).

### Sección 1 — Panel "Trabajo" + capa de datos de la tarjeta de pulso

- **`domain/estadisticas/calculos.ts`** se extendió con `calcularCostoPorKm(gastos, viajes, desdeISO, hastaISO)` — la única función de la tabla de métricas que faltaba (cruza `domain/gastos` recién creado en Bloque 3 contra `domain/viajes`). Sigue siendo pura (recibe todo como parámetro, D-10), y devuelve `costoPorKm: null` en vez de una división por cero cuando no hay km todavía en el rango. `domain/estadisticas/types.ts` gana el tipo `CostoPorKm` y su comentario de cabecera se corrigió (ya no dice que "gastos no existe", eso era de antes de Bloque 3).
- **`features/trabajo/`** (nuevo) — un panel único que fusiona lo que antes eran 4 pantallas + una tarjeta nueva, todas como secciones internas con scroll (no pestañas):
  - `SeccionPulso.tsx` — neto de hoy (ingresos − gastos de hoy), km de hoy, costo/km de hoy, y si hay jornada abierta: horas trabajadas/muertas y $/hora (trabajada vs. con espera), usando `calcularTiempoJornada`/`calcularRentabilidadPorHora` (ya existían desde Bloque 2) y el `calcularCostoPorKm` nuevo. **Sin animación ni tema** — eso es el ítem 13 completo, la parte visual, pendiente.
  - `SeccionViajesYJornada.tsx`, `SeccionMantenimiento.tsx`, `SeccionGastos.tsx`, `SeccionEstadisticas.tsx` — es la MISMA lógica exacta que tenían `ViajesScreen.tsx`/`MantenimientoScreen.tsx`/`GastosScreen.tsx`/`EstadisticasScreen.tsx` (ningún store se tocó, D-3), solo se les quitó el `<section className="pantalla"><h1>` propio y se les bajó el título a `<h2>` para vivir dentro del panel único.
  - `TrabajoScreen.tsx` — compone las 5 piezas de arriba dentro de un solo `<section className="pantalla">`.
- Las 4 pantallas viejas (`features/viajes/ViajesScreen.tsx`, `features/mantenimiento/`, `features/gastos/`, `features/estadisticas/`) **se borraron** (y sus carpetas, si quedaron vacías) — no se dejaron como código muerto/huérfano, mismo criterio que el hallazgo de la Fase 1 (auditoría del proyecto viejo) dijo que había que evitar.

### Sección 2 — Panel "Casa y Deudas" + MIA como burbuja flotante

- **`features/casaYDeudas/`** (nuevo) — `CasaYDeudasScreen.tsx` con un toggle simple de dos botones (Deudas / Hogar, mismo patrón de sub-tabs que ya tenía NOAH) que muestra `SeccionDeudas.tsx` o `SeccionHogar.tsx` — misma lógica exacta que tenían `DeudasScreen.tsx`/`HogarScreen.tsx`, solo reempaquetada. "Ahorro" (mencionado en la estructura de paneles acordada) **no se agregó como sub-tab** porque `domain/ahorro` no existe todavía como dominio — no se inventó una sub-sección vacía.
- **`features/mia/MiaBurbuja.tsx`** (nuevo) — reemplaza la ruta `/conversacion`. Es exactamente la misma lógica que tenía `ConversacionScreen.tsx` (mismo `domain/conversacion`, sin tocar ese store), reempaquetada como un botón circular fijo (`position: fixed`) que abre/cierra un panel flotante encima de lo que sea que esté en pantalla. **Sin animación ni ícono de micrófono todavía** — un botón que dice "MIA", a propósito, hasta que se elija el tema.
- `features/conversacion/ConversacionScreen.tsx` **se borró** (fusionada en la burbuja).
- **`App.tsx` reescrito**: la barra de navegación bajó de 9 rutas a 4 (Trabajo / Casa y Deudas / Balance / Cuenta / Planes) + `<MiaBurbuja/>` renderizada afuera de `<Routes>`, visible en cualquier panel. `features/auth/CuentaScreen.tsx` tenía un `navegar('/conversacion')` después del login que se habría roto (ruta inexistente) — se corrigió a `navegar('/')`, ya que MIA ahora se abre desde cualquier panel, no hace falta redirigir a una ruta especial.
- Se verificó a mano (grep) que ninguna pantalla restante siguiera importando o navegando hacia una de las rutas/archivos borrados.

**No se pudo compilar ni correr esto ni una vez** — mismo límite de siempre (sin red en este entorno para `npm install`). Es la primera vez que se toca `App.tsx` con esta cantidad de archivos movidos a la vez, así que vale la pena que la próxima sesión (o el usuario, si consigue correrlo) haga un `npm run build` completo antes de seguir — un typo de importación acá sería más caro de rastrear que en cambios más chicos.

**Siguiente paso real:** con esto, del Bloque 4 solo faltan los ítems de diseño (9, 10, 14) y terminar de vestir la tarjeta de pulso con animación (parte visual del ítem 13) — es decir, todo lo que el usuario pidió dejar para después. Cuando el usuario quiera seguir con eso, lo primero es la pregunta que quedó pendiente desde antes: **elegir el tema** (Tema 1 neutro claro / Tema 2 oscuro tipo Uber Driver / Tema 3 estilo NOAH) — sigue siendo una decisión bloqueante, no se puede escribir CSS real sin ella.

## Estructura del repo (tal como va hoy)

```
mia/
  PLAN-MAESTRO.md          ← este archivo, léelo primero
  docs/
    FASE2-ARQUITECTURA.md
  app/                      ← cliente móvil (Capacitor + React + TS)
    src/
      domain/
        viajes/             ← primer módulo de referencia, ya iniciado (Fase 4)
          types.ts
          repository.ts
          store.ts
          api.ts            ← Fase 13: sube un viaje a POST /sync/viajes
          sync.ts           ← Fase 13: recorre la cola pendiente, best-effort
        jornada/            ← agrupa viajes de un turno (Fase 4)
        mantenimiento/      ← Fase 6: catálogo + personalizados + alertas
          types.ts
          reglas.ts
          repository.ts
          store.ts
        estadisticas/       ← Fase 6: solo funciones puras, sin repository/store propio
          types.ts
          calculos.ts
        conversacion/       ← Fase 10: voz + conversación continua, sin repository (D-11)
          types.ts
          voz.ts            ← STT/TTS, patrón nativo/web igual que viajes/gps.ts
          api.ts            ← llama a POST /ai/conversacion
          store.ts
        auth/               ← Fase 7 (cliente): sesión, sin repository (el token ya lo guarda lib/api.ts)
          types.ts
          api.ts            ← llama a POST /auth/registro|login|refrescar
          store.ts
        planes/             ← Fase 11 (cliente): solo lectura, sin repository (el backend es la fuente de verdad)
          types.ts
          api.ts            ← llama a GET /planes, GET /planes/actual
          store.ts
      features/
        trabajo/            ← Bloque 4: Panel "Trabajo" — fusiona viajes+jornada+mantenimiento+gastos+estadísticas
          TrabajoScreen.tsx
          SeccionPulso.tsx        ← neto/km/costo-por-km/$-por-hora de hoy, sin animación (visual = pendiente)
          SeccionViajesYJornada.tsx
          SeccionMantenimiento.tsx
          SeccionGastos.tsx
          SeccionEstadisticas.tsx
        casaYDeudas/        ← Bloque 4: Panel "Casa y Deudas" — Deudas/Hogar con sub-tabs
          CasaYDeudasScreen.tsx
          SeccionDeudas.tsx
          SeccionHogar.tsx
        mia/                ← Bloque 4: MIA como burbuja flotante (ya no es una ruta)
          MiaBurbuja.tsx
        viajes/
          AgregarViajeManualScreen.tsx  ← Bloque 2, ítem 4 — sigue siendo ruta propia, no se fusiona
        balance/
          BalanceScreen.tsx   ← Panel "Balance" propio, no se fusiona con Trabajo (ver estructura de paneles)
        auth/
          CuentaScreen.tsx  ← login/registro en una sola pantalla (Fase 7/10, D-13)
        planes/
          PlanesScreen.tsx  ← plan actual + catálogo, sin botón de compra todavía (Fase 11, D-14)
      design/
        tokens.css          ← tema genérico (global) + `.tema-trabajo` (Bloque 4 visual,
                                SOLO Panel Trabajo, scoped a propósito — ver PLAN)
      lib/
        api.ts              ← Fase 10: primer cliente HTTP real hacia server/ (D-11)
    android/                ← plugins nativos (burbuja, alarma) copiados del proyecto viejo (D-1),
                                más RECORD_AUDIO en el manifiesto (Fase 10)
  server/                   ← backend (Node + TS + Express + Prisma + Postgres)
    prisma/
      schema.prisma         ← Usuario, TokenRefresco, Plan, PlanDeUsuario
    src/
      config/
        env.ts              ← única puerta de entrada a variables de entorno
      lib/
        prisma.ts           ← PrismaClient único para todo el proceso
        logSeguridad.ts     ← Fase 12: única puerta de salida para eventos de seguridad
      http/
        asyncHandler.ts
        errorHandler.ts     ← único lugar que decide status/forma del JSON de error
        rateLimit.ts         ← Fase 12: rate limiting en memoria, ahora loguea al bloquear
      modules/
        auth/               ← Fase 7: registro, login, refresco (JWT + refresh opaco), middleware
        plans/              ← Fase 7: plan gratis automático. Play Billing real = Fase 11
        sync/                ← Fase 13 (EN CURSO): types.ts, schemas.ts, repository.ts,
                                service.ts, routes.ts — POST /sync/viajes, dedupe por id +
                                verificación de pertenencia. Solo viajes (ver D-16).
        ai/                  ← Fase 8 y 9 hechas con salvedades: reglas.ts, router.ts,
                                respuestas.ts, clasificadorIA.ts (stub) — Fase 8;
                                analisis.ts, contextoCompacto.ts, proveedorIA.ts (stub) — Fase 9;
                                conversacion.ts (Fase 10, EN CURSO) — decide Intent Router vs.
                                proxy de IA por turno, reutiliza el stub de proveedorIA.ts.
                                Proveedor de IA real sin decidir en ninguna de las tres.
        billing/             ← Fase 11 (EN CURSO): types.ts, service.ts, routes.ts escritos;
                                googlePlay.ts es un stub a propósito (verificadorSinConfigurar,
                                503) — no hay cuenta de desarrollador de Google Play todavía.
```
